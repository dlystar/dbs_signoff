import { useState, useEffect, useMemo, useRef } from 'react'
import { Form4 as Form} from '@chaoswise/ui'
import {getUserGroupInfoByIds} from '../api'
import DoVisibleRange from '@/components/DoVisibleRange'
import useDropDwonStyle from '../useDropDwonStyle'
import {getUserGroupByExactName} from '@/services/douc'
const Group = ({value, onChange, row, disabled, type = 'testing', ...props}) => {
    const {uatGroupIds = [], nUatGroupIds = []} = window.DOSM_CUSTOM_DBS.signoff?.testingSignoff || {}
    const {arcCTAndEASREGroupIds = [], arcOtherGroupIds} = window.DOSM_CUSTOM_DBS.signoff?.heightenSignoff || {}
    const {IDRGroupIds = [], ISSGroupIds = [], DRteamGroupIds = [], StorageteamGroupIds = []} = window.DOSM_CUSTOM_DBS.signoff?.otherSignoff || {}
    const {HADRFlipGroupIds = [],  DataCenterOPSGroupIds = [], ImpactToMainframeGroupIds = [], D4DGroupIds = [], BUGroupIds = []} = window.DOSM_CUSTOM_DBS.signoff?.projectCutoverSignoff || {}
    const {form, onValuesChange, formData} = row    
    const [uatList, setUatList] = useState([])
    const [nUatlist, setNUatList] = useState([])
    const [arcList, setArcList] = useState([])
    const selectRef = useRef()
    const groupRef = useRef({})
    const {open, setOpen} = useDropDwonStyle(selectRef, props.id, groupRef)
    const [groupIds, setGroupIds] = useState([])
    const key = props.id.split('_').splice(1)
    key.splice(2,1,'signOffType')
    const signOffType = Form.useWatch(key, form)    

    useEffect(() => {
        if (type === 'testing') {
            return setGroupIds(signOffType?.includes('UAT') ? uatGroupIds : nUatGroupIds)
        }
        if(signOffType?.includes('IDR Signoff')){
            return setGroupIds(IDRGroupIds)
        }
        if(signOffType?.includes('ISS Signoff')){
            return setGroupIds(ISSGroupIds)
        }
        if(signOffType?.includes('Code Checker Signoff')){
            window.parent.FORM_ACTIONS.getFieldState('ApproverGroup1', state => {
                const changeOptions = state?.props?.['x-props']?.changeOptions || []
                setGroupIds(changeOptions.map(i => Number(i.groupId)))
            })
        }
        if(signOffType?.includes('DR team Signoff')){
            return setGroupIds(DRteamGroupIds)
        }
        if(signOffType?.includes('Storage team Signoff')){
            return setGroupIds(StorageteamGroupIds)
        }

        if(signOffType?.includes('HA & DR Flip Signoff')){
            return setGroupIds(HADRFlipGroupIds)
        }
        if(signOffType?.includes('Data Center OPS (Batch) Signoff')){
            return setGroupIds(DataCenterOPSGroupIds)
        }
        if(signOffType?.includes('Impact To Mainframe Signoff')){
            return setGroupIds(ImpactToMainframeGroupIds)
        }
        if(signOffType?.includes('Design For Data (D4D) SignOff')){
            return setGroupIds(D4DGroupIds)
        }
        if(signOffType?.includes('BU/Application Owner Signoff')){
            return setGroupIds(BUGroupIds)
        }
        if(signOffType?.includes('ARC Signoff')){
            if(formData?.lob_value == 'CT' || formData?.lob_value == 'EASRE'){
                return setGroupIds(arcCTAndEASREGroupIds)
            }else{
                getUserGroupByExactName({
                    licFeatures: '',
                    groupName: 'PSG_DBSGOV_ARC_' + formData?.lob_value,
                }).then(res => {
                    const arcOtherGroupIds = res?.data?.list?.map(i => i.groupId) || []
                    setGroupIds(arcOtherGroupIds)
                })
            }
        }
    }, [type, signOffType, formData])
    
    const handleChange = (val) => {
        // group类型变更，清空user
        const key = props.id.split('_').splice(1)
        key.splice(2,1,'signOffUser')
        const namePath = key.map(i => isNaN(i) ? i : Number(i))
        form.setFieldValue(namePath, undefined)
        onChange(val)
        onValuesChange(row.name, 'signOffUserGroup', val)
    }

    const getPopupContainer = (e) => {
        const {inIframe} = window.DOSM_CUSTOM_DBS.signoff
        if(inIframe){
            return window.parent?.document?.body
        }else{
            return document.body
        }
    }

    const _list = useMemo(() => {
        if (type === 'testing') {
            // 如果Signoff Type中包含"UAT"，则该条signoff 的Group必须为"SVP&Above"
            return signOffType?.includes('UAT') ? uatList : nUatlist
        }
        return arcList
    }, [type, signOffType, uatList, nUatlist, arcList])

    return (
        <div ref={selectRef} key={groupIds?.join(',')}>
            <DoVisibleRange 
                visibleRef={groupRef}
                types={['group']}
                crossTenant={true}
                userStatus={false}
                group={{
                    multiple: false,
                    visibleGroupIds: groupIds,
                    onlyGroup: true,
                }}
                value={value}
                onChange={handleChange}
                getPopupContainer={getPopupContainer}
                dropDownOverlayClassName={props.id}
                setOpen={setOpen}
                disabled={disabled || signOffType?.includes('MD Delegate Signoff')}
                placeholder="Please select"
                open={open}
            />
        </div>
    )
}

export default Group
