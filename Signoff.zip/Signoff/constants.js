export const SIGNOFF_GROUP = {
    TESTING_SIGNOFF: 'TestingSignoff',
    PROCUTOVER_SIGNOFF: 'ProCutoverSignoff',
    OTHER_SIGNOFFS: 'OtherSignoffs',
    OPTIONAL_ARTEFACTS: 'OptionalArtefacts',
    HEIGHTENED_SIGNOFF: 'HeightenedSignoff',
    IDR_SIGNOFF: 'IDRSignoff'
}

export default {
    SIGNOFF_GROUP
}