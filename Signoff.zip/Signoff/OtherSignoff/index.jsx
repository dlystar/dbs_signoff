import React, { useState, useRef, useEffect } from 'react';
import {CWTable, Form4 as Form, Space, Button, Modal, Checkbox, Input} from '@chaoswise/ui'
import { observer } from '@chaoswise/cw-mobx';
import otherSignoffStore from '../TestingSignoff/store';
import { uniqBy, sortBy } from 'lodash';
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons';
import Status from '../TestingSignoff/components/Status';
import SignOffType from '../TestingSignoff/components/SignoffType';
import RejectionReason from '../TestingSignoff/components/RejectionReason';
import SignOffUserGroup from '../components/Group'
import SignOffUser from '../TestingSignoff/components/User';
import Artefact from '../TestingSignoff/components/Artefact';
import { getFlatSchema } from '@/pages/BusinessSetting/ProcessManagement/CreateNew/FormDesign/FormEngine/FormRender/util/handleSchema';
import {
  signoffInsertBatch,
  signoffUpdate,
  signoffApproved,
  signoffRejected,
  signoffSendEmail,
  getSignOffById,
  getSignOffListByWorkOrderId,
  signoffStatus,
  signoffDeleteBatch
} from '../api';
import { SIGNOFF_GROUP } from '../constants';
import { helper } from '@/utils/T';
const OtherSignoff = () => {
  const [tableLoading, setTableLoading] = useState(false);
  const [form] = Form.useForm();
  const { signoffTypeOptions, setSignoffTypeOptions, formData, updateState, orderInfo } = otherSignoffStore;
  const crStatus = formData?.crStatus_value || orderInfo?.formData?.crStatus_value;
  const containerRef = useRef();
  const initedRef = useRef(false)
  let accountId = JSON.parse(localStorage.getItem('dosm_loginInfo'))?.user?.accountId || '110';
  let topAccountId = JSON.parse(localStorage.getItem('userConfig'))?.topAccountId || accountId;
  // Form changes will reset signoff approval status
  const shouldResetSignoff = (index, key, val) => {
    const tableData = form.getFieldValue('otherSignoff')
    const rowData = tableData[index]
    // When crStatus is new, changing user field
    // When crStatus is new, changing artefact field
    if(crStatus && rowData.status != 'WAITSEND'){
        if(key === 'signOffUser' && val){
            return true
        }
        if(key === 'artifact' && val){
            return true
        }
    }
    return false
  }
  const arrayIsEqual = (arr1, arr2) => {
    if (!Array.isArray(arr1) || !Array.isArray(arr2)) return false;
    return JSON.stringify(arr1) === JSON.stringify(arr2);
  };
  const includes = function () {
    const arr = arguments[0]
    if(!arr) return false
    let has = false
    for(let i = 1; i < arguments.length; i++){
      if(arr.includes(arguments[i])) has = true
    }
    return has
  }
  const tableHasFormData = (key, value, tableData) => {
    return tableData.some(item => arrayIsEqual(item[key], [value]));
  };

  const newRow = (signoffTypeValue) => {
    return {
      signOffType: [signoffTypeValue],
      signOffUser: undefined,
      artifact: undefined,
      status: 'WAITSEND',
      group: undefined,
      rejectionReason: undefined
    };
  };

  const fieldChange = helper.debounce((formData, _tableData, _orderInfo, onlyUpdateOptions) => {
    console.log('---formData---', formData)
    // const flatSchame = getFlatSchema(orderInfo?.schema || _orderInfo?.schema);
    const _signoffTypeOptions = JSON.parse(JSON.stringify(signoffTypeOptions));
    const tableData = JSON.parse(JSON.stringify(_tableData || []));
    const {signoffTypes} =  window.DOSM_CUSTOM_DBS.signoff.otherSignoff
    let newRows = []
    let deleteRows = []
    signoffTypes.forEach(signoffType => {
      const name = signoffType.formKey;
      if (name) {
        let conditionTrue = formData[name] && signoffType.conditionValue.includes(formData[name]) && !tableHasFormData('signOffType', signoffType.signoffType, tableData)
        let conditionFalse = !signoffType.conditionValue.includes(formData[name]) && tableHasFormData('signOffType', signoffType.signoffType, tableData)
        if(signoffType.signoffType == 'IDR Signoff'){
          conditionTrue = formData['lob_value'] == 'CES' && conditionTrue
          conditionFalse = formData['lob_value'] != 'CES' || conditionFalse
        }
        // Add signoff type if condition is met and type doesn't exist
        if (conditionTrue) {
          tableData.push(newRow(signoffType.signoffType));
          newRows.push(newRow(signoffType.signoffType))
          _signoffTypeOptions.push({ label: signoffType.signoffType, value: signoffType.signoffType });
        }
        // Remove signoff type if condition is not met but type exists
        if (conditionFalse) {
          const index = tableData.findIndex(item => arrayIsEqual(item.signOffType, [signoffType.signoffType]));
          if (index > -1){
            let deleteRow = tableData.splice(index, 1)
            deleteRows = deleteRows.concat(deleteRow.filter(i => i.id))
          }
          const _index = _signoffTypeOptions.findIndex(i => i.value === signoffType.signoffType);
          if (_index > -1) _signoffTypeOptions.splice(_index, 1);
        }
      }
    });
    console.log(`uniqBy(_signoffTypeOptions, 'value')`, _tableData, tableData)
    // Update options first, then form values
    if (!onlyUpdateOptions) {
      if (!arrayIsEqual(_tableData, tableData)) {
        if(formData.crStatus || crStatus){
          if(deleteRows.length > 0){
            signoffDeleteBatch(deleteRows.map(item => item.id)).then(res => {
              getSignoffs()
            })
          }
          if(newRows.length > 0){
            signoffInsertBatch(newRows.map(item => {
              return {
                ...item,
                signOffUserGroup: JSON.stringify(item.signOffUserGroup),
                signOffUser: JSON.stringify(item.signOffUser),
                artifact: JSON.stringify(item.artifact),
                signOffType: JSON.stringify(item.signOffType),
                signOffGroup: SIGNOFF_GROUP.OTHER_SIGNOFFS,
                topAccountId,
                accountId,
                workOrderId: orderInfo.workOrderId
              }
            })).then(() => {
              getSignoffs()
            })
          }
        }else{
          setTimeout(() => {
            form.setFieldValue('otherSignoff', tableData);
          }, 100);
        }
      }
    }
  },300);

  const handleMessage = (event) => {
    const { data } = event;
    switch (data.eventType) {
      case 'onFormMount':
        console.log('Form initialized', data.orderInfo);
        updateState({ orderInfo: data.orderInfo });
        if(data.orderInfo.formData?.crStatus && !initedRef.current){
          getSignoffs(data.orderInfo.formData, data.orderInfo.workOrderId)
          initedRef.current = true
        }
        break;
      case 'onFormValuesChange':
        const otherSignoff = form.getFieldValue('otherSignoff') || [];
        fieldChange(data.values, otherSignoff);
        updateState({ formData: data.values });
        break;
      // Form submission success
      case 'onOrderCreateSuccess':
        // When crStatus is new, insert data
        console.log('Form submitted', data)
        if (!crStatus) {
          console.log('Form submitted', data)
          const tableData = form.getFieldValue('otherSignoff')
          const params = tableData.map(item => {
            return {
              ...item,
              signOffUserGroup: JSON.stringify(item.signOffUserGroup),
              signOffUser: JSON.stringify(item.signOffUser),
              artifact: JSON.stringify(item.artifact),
              signOffType: JSON.stringify(item.signOffType),
              signOffGroup: SIGNOFF_GROUP.OTHER_SIGNOFFS,
              topAccountId,
              accountId,
              workOrderId: data.orderId
            }
          })
          window.parent.fetch(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/insertBatch`, {
            method: 'POST',
            body: JSON.stringify(params),
            headers: { 'Content-Type': 'application/json' }
          })
        }
        break;
      default:
        console.log('Unhandled event type:', data.eventType);
        break;
    }
  };

  // Get signoffs for the current work order
  const getSignoffs = (formData, workOrderId) => {
    setTableLoading(true);
    const orderId = orderInfo.workOrderId || workOrderId
    const status = crStatus || formData?.crStatus_value
    getSignOffListByWorkOrderId({ workOrderId: orderId, signOffGroup: SIGNOFF_GROUP.OTHER_SIGNOFFS, })
      .then(res => {
        let data = res?.data?.map(item => ({
          ...item,
          signOffUserGroup: JSON.parse(item.signOffUserGroup),
          signOffUser: JSON.parse(item.signOffUser),
          artifact: JSON.parse(item.artifact),
          signOffType: JSON.parse(item.signOffType),
        }));
        
        const otherSignoffData = data?.filter(i => i.signOffGroup === SIGNOFF_GROUP.OTHER_SIGNOFFS);
        form.setFieldValue('otherSignoff', sortBy(otherSignoffData, 'id'));
        // This field does not need to send for approval, only needs to upload attachments. In Create state, it is not displayed; after Create is converted to Open phase, it is displayed but cannot be filled in; after Open phase is converted to Approved phase, it triggers email notification and can be filled in
        if(status === 'Open'){
          let typeOptions = [];
          let params = []
          console.log('formData', formData);
          if(!tableHasFormData('signOffType', 'Technical Live Verification (LV) Signoff', otherSignoffData) && ["1feabdb62e16477eb82a0e56838d7893", "84ca02b229a74c798aacf16e3afa0ea9"].includes(formData['liveVerificationAfterImplementat'])){
            typeOptions.push('Technical Live Verification (LV) Signoff')
            params.push({
              signOffUserGroup: "[]",
              signOffUser: "[]",
              artifact: "[]",
              signOffType: '["Technical Live Verification (LV) Signoff"]',
              signOffGroup: SIGNOFF_GROUP.OTHER_SIGNOFFS,
              topAccountId,
              accountId,
              workOrderId: orderId,
              status: 'WAITSEND'
            })
          }
          if(!tableHasFormData('signOffType', 'Business Live Verification (LV) Signoff', otherSignoffData) && ['84ca02b229a74c798aacf16e3afa0ea9'].includes(formData['liveVerificationAfterImplementat'])){
            typeOptions.push('Business Live Verification (LV) Signoff')
            params.push({
              signOffUserGroup: "[]",
              signOffUser: "[]",
              artifact: "[]",
              signOffType: '["Business Live Verification (LV) Signoff"]',
              signOffGroup: SIGNOFF_GROUP.OTHER_SIGNOFFS,
              topAccountId,
              accountId,
              workOrderId: orderId,
              status: 'WAITSEND'
            })
          }
          if(params.length > 0){
            window.fetch(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/insertBatch`, {
              method: 'POST',
              body: JSON.stringify(params),
              headers: { 'Content-Type': 'application/json' }
            }).then(res => {
              getSignoffs(formData, orderId)
            })
          }
        }
        // When CR status is ‘Approved’, if the field 'Checker 'is not empty, the system adds an Implementation Checker Signoff under Signoff Tab.
        if(status === 'Approved'){
          let typeOptions = [];
          let params = []
          console.log('formData', formData, otherSignoffData);
          if(!tableHasFormData('signOffType', 'Implementation Checker Signoff', otherSignoffData) && formData['checker']){
            typeOptions.push('Implementation Checker Signoff')
            params.push({
              signOffUserGroup: "[]",
              signOffUser: "[]",
              artifact: "[]",
              signOffType: '["Implementation Checker Signoff"]',
              signOffGroup: SIGNOFF_GROUP.OTHER_SIGNOFFS,
              topAccountId,
              accountId,
              workOrderId: orderId,
              status: 'WAITSEND'
            })
          }
          if(params.length > 0){
            window.fetch(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/insertBatch`, {
              method: 'POST',
              body: JSON.stringify(params),
              headers: { 'Content-Type': 'application/json' }
            }).then(res => {
              getSignoffs(formData, orderId)
            })
          }
        }
        setTableLoading(false);
      })
      .catch(err => {
        setTableLoading(false);
        console.error(err);
      });
  };

  const formDisabled = () => {
    if(orderInfo.createdBy){
      let userInfo = localStorage.getItem('dosm_loginInfo')
      userInfo = JSON.parse(userInfo)
      if(userInfo.user.userId == orderInfo.createdBy){
          return false
      }else{
          return true
      }
    }else{
      return false
    }
  };

  const approval = (rowNum) => {
    const tableData = form.getFieldValue('otherSignoff');
    const rowData = tableData[rowNum];
    signoffApproved({ signOffId: rowData.id }).then(res => {
      window.parent.prompt.success('Approved');
      getSignoffs();
    }).catch(err => {
      window.parent.prompt.error(err.msg)
    })
  };

  const reject = (rowNum) => {
    const tableData = form.getFieldValue('otherSignoff');
    const rowData = tableData[rowNum];
    let rejectionReason = ''
    const onChange = (e) => {
      rejectionReason = e.target.value
    }
    Modal.confirm({
      title: 'Rejection Reason',
      icon: null,
      content: <div><Input.TextArea onChange={onChange} /></div>,
      getContainer(){
        const {inIframe} = window.DOSM_CUSTOM_DBS.signoff
        if(inIframe){
          return window.parent?.document?.body
        }else{
          return document.body
        }
      },
      onOk(){
        return signoffRejected({signOffId: rowData.id, rejectionReason: rejectionReason}).then(res => {
          window.parent.prompt.success('Rejected')
          getSignoffs()
        }).catch(err => {
          window.parent.prompt.error(err.msg)
        })      
      },
    })
  };

  const sendEmail = (rowNum) => {
    const tableData = form.getFieldValue('otherSignoff');
    const rowData = tableData[rowNum];
    let clickable = false
    const onChange = (e) => {
      clickable = e.target.checked
      if (e.target.checked) {
        window.parent.sendEmail_button.removeAttribute('disabled')
      } else {
        window.parent.sendEmail_button.setAttribute('disabled', true)
      }
    }
    setTimeout(() => {
      window.parent.sendEmail_button.setAttribute('disabled', true)
    }, 60)
    Modal.confirm({
      title: 'Delarrtion',
      content: <span><Checkbox onChange={onChange} style={{ marginRight: 10 }} />I am fully responsible & accountable for all the artefacts uploaded and attest that it does not contain any customer, sensitive, or Pll data.</span>,
      okButtonProps: { id: 'sendEmail_button' },
      getContainer() {
        const { inIframe } = window.DOSM_CUSTOM_DBS.signoff
        if (inIframe) {
          return window.parent?.document?.body
        } else {
          return document.body
        }
      },
      onOk() {
        return signoffSendEmail({ signOffId: rowData.id }).then(res => {
          console.log('res', res);
          window.parent.prompt.success('Successfully send')
          getSignoffs()
        }).catch(err => {
          console.log('err', err);
          window.parent.prompt.error(err.msg)
        })
      },
    })
  };

  const onValuesChange = (index, key, val) => {
    console.log('Updating value -', key, val);
    // Update in real-time after the work order is created
    const tableData = form.getFieldValue('otherSignoff')
    const rowData = tableData[index]
    if (crStatus) {
      signoffUpdate({
        ...rowData,
        signOffUserGroup: JSON.stringify(rowData.signOffUserGroup),
        signOffUser: JSON.stringify(rowData.signOffUser),
        artifact: JSON.stringify(rowData.artifact),
        signOffType: JSON.stringify(rowData.signOffType),
      }).then(res => {
        let signOffType = rowData?.signOffType?.[0]
        if (crStatus && key === 'artifact' && ['Technical Live Verification (LV) Signoff', 'Business Live Verification (LV) Signoff','DCON Signoff', 'Implementation Checker Signoff'].includes(signOffType)) {
          signoffStatus({ signOffId: rowData.id, status: 'APPROVED' }).then(res => {
            getSignoffs()
          }).catch(err => {
            window.parent.prompt.error(err.msg)
          })
        }else{
          // If the field value changes and involves resetting the signoff task, reset the signoff task
          if (shouldResetSignoff(index, key, val)) {
            signoffStatus({ signOffId: rowData.id, status: 'WAITSEND' }).then(res => {
              getSignoffs()
            }).catch(err => {
              window.parent.prompt.error(err.msg)
            })
          } else {
            getSignoffs()
          }
        }
      })
    }
  }

  // Form and window message effects
  useEffect(() => {
    window.parent.postMessage({
      eventType: 'onChildFormInit',
      height: containerRef.current.clientHeight
    }, '*');

    window.formActions = {
      submit: () => {
        return new Promise((resolve, reject) => {
          form.validateFields()
            .then(values => {
              resolve({ values });
            })
            .catch(errors => {
              window.parent.postMessage({ 
                eventType: 'onChildFormValidateError', 
                errors: errors.errorFields 
              }, '*');
              document.querySelector('.ant-form-item-explain-error')?.scrollIntoView({ behavior: 'smooth' });
              const error = errors.errorFields.map(item => ({
                name: item.name,
                messages: item.errors
              }));
              reject(error);
            });
        });
      },
      getFieldsValue: () => {
        return Promise.resolve({
          values: form.getFieldsValue()
        });
      }
    };
  }, []);

  useEffect(() => {
    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [orderInfo, signoffTypeOptions, crStatus]);

  useEffect(() => {
    setSignoffTypeOptions([
      {
          "label": "ISS Signoff",
          "value": "ISS Signoff"
      },
      {
          "label": "Code Checker Signoff",
          "value": "Code Checker Signoff"
      },
      {
          "label": "DR team Signoff",
          "value": "DR team Signoff"
      },
      {
          "label": "Storage team Signoff",
          "value": "Storage team Signoff"
      },
      {
          "label": "DCON Signoff",
          "value": "DCON Signoff"
      },
      {
        "label": "Implementation Checker Signoff",
        "value": "Implementation Checker Signoff",
      },
      {
        "label": "Technical Live Verification (LV) Signoff",
        "value": "Technical Live Verification (LV) Signoff",
      },
      {
        "label": "Business Live Verification (LV) Signoff",
        "value": "Business Live Verification (LV) Signoff",
      },
      {
        label: 'IDR Signoff', 
        value: 'IDR Signoff'
      }
    ])
  },[])
  return (
    <div ref={containerRef}>
      <Form form={form} name="signoff">
        <Form.List name="otherSignoff">
          {(fields, { add, remove }) => (
            <>
              <CWTable
                loading={tableLoading}
                dataSource={fields?.map((i) => ({ ...i, remove, form, signoffTypeOptions: signoffTypeOptions, onValuesChange }))}
                pagination={false}
                rowKey="key"
                scroll={{ x: 1200 }}
                columns={[
                  {
                    title: 'Status',
                    key: 'status',
                    width: '150px',
                    render: (_, row) => {
                      const tableData = form.getFieldValue('otherSignoff');
                      const rowData = tableData[row.name] || {}
                      if(includes(rowData.signOffType, 'DCON Signoff', 'Technical Live Verification (LV) Signoff', 'Business Live Verification (LV) Signoff', 'Implementation Checker Signoff')) return null
                      return <Form.Item name={[row.name, 'status']}>
                        <Status />
                      </Form.Item>
                    }
                  },
                  {
                    title: <span><span style={{color: '#f5222d'}}>*</span>Signoff Type</span>,
                    key: 'signOffType',
                    width: '200px',
                    render: (_, row) => {
                      return <Form.Item 
                        name={[row.name, 'signOffType']} 
                        rules={[{ required: true, message: 'Please select Signoff Type' }]}
                      >
                        <SignOffType row={row} disabled={true} />
                      </Form.Item>
                    }
                  },
                  {
                    title: <span><span style={{color: '#f5222d'}}>*</span>Group</span>,
                    key: 'Group',
                    width: '200px',
                    render: (_, row) => {
                      const tableData = form.getFieldValue('otherSignoff');
                      const rowData = tableData[row.name] || {}
                      if(includes(rowData.signOffType, 'DCON Signoff', 'Technical Live Verification (LV) Signoff', 'Business Live Verification (LV) Signoff', 'Implementation Checker Signoff')) return null
                      return <Form.Item 
                        name={[row.name, 'signOffUserGroup']} 
                        rules={[{ required: true, message: 'Please select Group' }]}
                      >
                        <SignOffUserGroup type="otherSignoff" row={row} disabled={formDisabled()} />
                      </Form.Item>
                    }
                  },
                  {
                    title: <span><span style={{color: '#f5222d'}}>*</span>Signer</span>,
                    key: 'User',
                    width: '200px',
                    render: (_, row) => {
                      const tableData = form.getFieldValue('otherSignoff');
                      const rowData = tableData[row.name] || {}
                      if(includes(rowData.signOffType, 'DCON Signoff', 'Technical Live Verification (LV) Signoff', 'Business Live Verification (LV) Signoff', 'Implementation Checker Signoff')) return null
                      return <Form.Item 
                        name={[row.name, 'signOffUser']} 
                        rules={[{ required: true, message: 'Please select User' }]}
                      >
                        <SignOffUser row={row} disabled={formDisabled()} />
                      </Form.Item>
                    }
                  },
                  {
                    title: <span><span style={{color: '#f5222d'}}></span>Artefact</span>,
                    key: 'artifact',
                    width: '200px',
                    render: (_, row) => {
                      const tableData = form.getFieldValue('otherSignoff');
                      const rowData = tableData[row.name] || {}
                      let disabled = formDisabled() || !['New', 'Reopen', undefined, '', null].includes(crStatus)
                      let rules = [{ required: true, message: 'Please upload artefact' }]
                      const needArtefactSignoffs = ['Code Checker Signoff', 'DCON Signoff']
                      if(!needArtefactSignoffs.includes(rowData.signOffType?.[0])){
                        rules = []
                      }
                      if(includes(rowData.signOffType, 'DCON Signoff', 'Technical Live Verification (LV) Signoff', 'Business Live Verification (LV) Signoff', 'Implementation Checker Signoff') && ['New', 'Reopen','Approved'].includes(crStatus)){
                        disabled = false
                        if(crStatus = 'Approved'){
                          rules = [{ required: true, message: 'Please upload artefact' }]
                        }
                      }  
                      
                      if(includes(rowData.signOffType, 'Technical Live Verification (LV) Signoff', 'Business Live Verification (LV) Signoff')){
                        if(crStatus != 'Approved'){
                          disabled = true
                        }
                        const Implementation_Time  = formData?.Implementation_Time || orderInfo?.formData?.Implementation_Time                        
                        if(Implementation_Time?.startDate && Implementation_Time?.startDate > new Date().getTime()){
                          disabled = true
                        }
                      }
                      return <Form.Item 
                        name={[row.name, 'artifact']} 
                        rules={rules}
                      >
                        <Artefact disabled={disabled} row={row} />
                      </Form.Item>
                    }
                  },
                  {
                    title: <span>Rejection Reason</span>,
                    key: 'rejectionReason',
                    width: '200px',
                    index: 'rejectionReason',
                    render(text, row){
                        return <Form.Item name={[row.name, 'rejectionReason']}>
                            <RejectionReason />
                        </Form.Item>
                    }
                  },
                  {
                    title: "Actions",
                    key: 'actions',
                    width: '20%',
                    fixed: 'right',
                    render: (_, row) => {
                      const tableData = form.getFieldValue('otherSignoff');
                      const rowData = tableData[row.name] || {}
                      const approver = rowData.signOffUser?.[0]?.userId
                      let userInfo = localStorage.getItem('dosm_loginInfo')
                      userInfo = JSON.parse(userInfo)
                      const currentUser = userInfo.user.userId
                      let showSend = () => {
                        return crStatus && 
                               (rowData.status === 'WAITSEND' || rowData.status === 'REJECTED') && 
                               rowData.signOffType && 
                               rowData.signOffUserGroup &&
                               rowData.signOffUser && 
                               currentUser == orderInfo.createdBy
                      };
                      let show = showSend()
                      if(includes(rowData.signOffType, 'DCON Signoff', 'Technical Live Verification (LV) Signoff', 'Business Live Verification (LV) Signoff', 'Implementation Checker Signoff')){
                        show = false
                      }
                      return (
                        <Space>
                          {rowData?.status === 'PENDING' && currentUser == approver && (
                            <Button type="primary" onClick={() => approval(row.name)}>
                              Approve
                            </Button>
                          )}
                          {rowData?.status === 'PENDING' && currentUser == approver && (
                            <Button danger onClick={() => reject(row.name)}>
                              Reject
                            </Button>
                          )}
                          {show && (
                            <Button type="primary" onClick={() => sendEmail(row.name)}>
                              Send
                            </Button>
                          )}
                        </Space>
                      );
                    }
                  }
                ]}
              />
            </>
          )}
        </Form.List>
      </Form>
    </div>
  );
};

export default observer(OtherSignoff);
