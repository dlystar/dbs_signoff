import React, { useState, useRef, useEffect } from 'react';
import {CWTable, Form4 as Form} from '@chaoswise/ui'
import { observer } from '@chaoswise/cw-mobx';
import optionalArtefactsStore from '../TestingSignoff/store';
import { uniqBy, sortBy } from 'lodash';
import SignOffType from '../TestingSignoff/components/SignoffType';
import Artefact from '../TestingSignoff/components/Artefact';
import { signoffUpdate,getSignOffListByWorkOrderId} from '../api';
import { SIGNOFF_GROUP } from '../constants';
const OptionalArtefacts = () => {
  const [tableLoading, setTableLoading] = useState(false);
  const [form] = Form.useForm();
  window.form = form
  const { signoffTypeOptions, setSignoffTypeOptions, formData, updateState, orderInfo } = optionalArtefactsStore;
  const crStatus = formData?.crStatus_value || orderInfo?.formData?.crStatus_value;
  const containerRef = useRef();
  const initedRef = useRef(false)
  let accountId = JSON.parse(localStorage.getItem('dosm_loginInfo'))?.user?.accountId || '110';
  let topAccountId = JSON.parse(localStorage.getItem('userConfig'))?.topAccountId || accountId;
  const handleMessage = (event) => {
    const { data } = event;
    switch (data.eventType) {
      case 'onFormMount':
        console.log('Form initialized', data.orderInfo);
        if(data.orderInfo.formData?.crStatus && !initedRef.current){
          getSignoffs(data.orderInfo.formData, data.orderInfo.workOrderId)
          initedRef.current = true
        }
        if(!data.orderInfo.formData?.crStatus && !initedRef.current){
          const {signoffTypes} = window.DOSM_CUSTOM_DBS.signoff.optionalArtefacts
          setSignoffTypeOptions(signoffTypes.map(i => ({label: i, value: i})))
          setTimeout(() => {
              form.setFieldValue('optionalArtefacts', signoffTypes.map(i => ({artifact: undefined, signOffType: [i]})))
          },1000)
          initedRef.current = true
        }
        break;
      case 'onFormValuesChange':
        console.log('Field changed');
        break;
      // 表单提交成功
      case 'onOrderCreateSuccess':
        // 在crStataus为new状态下，去插入数据
        console.log('表单提交啦', data)
        if (!crStatus) {
          console.log('表单提交啦', data)
          const tableData = form.getFieldValue('optionalArtefacts')
          const params = tableData.map(item => {
            return {
              ...item,
              status: 'APPROVED',
              signOffUserGroup: "[]",
              signOffUser: "[]",
              artifact: JSON.stringify(item.artifact),
              signOffType: JSON.stringify(item.signOffType),
              signOffGroup: SIGNOFF_GROUP.OPTIONAL_ARTEFACTS,
              topAccountId,
              accountId,
              workOrderId: data.orderId
            }
          })
          window.parent.fetch(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/insertBatch`, {
            method: 'POST',
            body: JSON.stringify(params),
            headers: { 'Content-Type': 'application/json' }
          })
        }
        break;
      default:
        console.log('Unhandled event type:', data.eventType);
        break;
    }
  };

  // Get signoffs for the current work order
  const getSignoffs = (formData, workOrderId) => {
    setTableLoading(true);
    const orderId = orderInfo.workOrderId || workOrderId
    const status = crStatus || formData?.crStatus_value
    getSignOffListByWorkOrderId({ workOrderId: orderId, signOffGroup: SIGNOFF_GROUP.OPTIONAL_ARTEFACTS, })
      .then(res => {
        let data = res?.data?.map(item => ({
          ...item,
          signOffUserGroup: JSON.parse(item.signOffUserGroup),
          signOffUser: JSON.parse(item.signOffUser),
          artifact: JSON.parse(item.artifact),
          signOffType: JSON.parse(item.signOffType),
        }));
        
        const otherSignoffData = data?.filter(i => i.signOffGroup === SIGNOFF_GROUP.OPTIONAL_ARTEFACTS,);
        form.setFieldValue('optionalArtefacts', sortBy(otherSignoffData, 'id'));
        
        let typeOptions = [];
        otherSignoffData.forEach(i => {
          typeOptions = typeOptions.concat(i.signOffType || []);
        });
        
        setSignoffTypeOptions(uniqBy(typeOptions.map(i => ({label: i, value: i})), 'value'));
        setTableLoading(false);
      })
      .catch(err => {
        setTableLoading(false);
        console.error(err);
      });
  };

  const formDisabled = () => {
    console.log('orderInfo', orderInfo);
    
    if(orderInfo.createdBy){
      let userInfo = localStorage.getItem('dosm_loginInfo')
      userInfo = JSON.parse(userInfo)
      if(userInfo.user.userId == orderInfo.createdBy){
          return false
      }else{
          return true
      }
    }else{
      return false
    }
  };


  const onValuesChange = (index, key, val) => {
    console.log('更新值啦   -', key, val);
    // 工单创建以后，实时更新
    const tableData = form.getFieldValue('optionalArtefacts')
    const rowData = tableData[index]
    if (crStatus) {
      signoffUpdate({
        ...rowData,
        signOffUserGroup: JSON.stringify(rowData.signOffUserGroup),
        signOffUser: JSON.stringify(rowData.signOffUser),
        artifact: JSON.stringify(rowData.artifact),
        signOffType: JSON.stringify(rowData.signOffType),
      }).then(res => {
        getSignoffs()
      })
    }
  }

  // Form and window message effects
  useEffect(() => {
    window.parent.postMessage({
      eventType: 'onChildFormInit',
      height: containerRef.current.clientHeight
    }, '*');

    window.formActions = {
      submit: () => {
        return new Promise((resolve, reject) => {
          form.validateFields()
            .then(values => {
              resolve({ values });
            })
            .catch(errors => {
              window.parent.postMessage({ 
                eventType: 'onChildFormValidateError', 
                errors: errors.errorFields 
              }, '*');
              document.querySelector('.ant-form-item-explain-error')?.scrollIntoView({ behavior: 'smooth' });
              const error = errors.errorFields.map(item => ({
                name: item.name,
                messages: item.errors
              }));
              reject(error);
            });
        });
      },
      getFieldsValue: () => {
        return Promise.resolve({
          values: form.getFieldsValue()
        });
      }
    };
  }, []);

  useEffect(() => {
    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [orderInfo, signoffTypeOptions, crStatus]);

  return (
    <div ref={containerRef}>
      <Form form={form} name="signoff">
        <Form.List name="optionalArtefacts">
          {(fields, { add, remove }) => (
            <>
              <CWTable
                loading={tableLoading}
                dataSource={fields?.map((i) => ({ ...i, remove, form, signoffTypeOptions: signoffTypeOptions, onValuesChange }))}
                pagination={false}
                rowKey="key"
                columns={[
                  {
                    title: <span><span style={{color: '#f5222d'}}>*</span>Signoff Type</span>,
                    key: 'signOffType',
                    width: '200px',
                    render: (_, row) => (
                      <Form.Item 
                        name={[row.name, 'signOffType']} 
                        rules={[{ required: true, message: 'Please select Signoff Type' }]}
                      >
                        <SignOffType row={row} disabled={true} />
                      </Form.Item>
                    )
                  },
                  {
                    title: <span><span style={{color: '#f5222d'}}></span>Artefact</span>,
                    key: 'artifact',
                    width: '200px',
                    render: (_, row) => (
                      <Form.Item 
                        name={[row.name, 'artifact']} 
                      >
                        <Artefact disabled={formDisabled()} row={row} />
                      </Form.Item>
                    )
                  },
                ]}
              />
            </>
          )}
        </Form.List>
      </Form>
    </div>
  );
};

export default observer(OptionalArtefacts);
