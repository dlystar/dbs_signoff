import React, { useState, useRef, useEffect } from 'react';
import {CWTable, Form4 as Form, Button, Space} from '@chaoswise/ui'
import { observer } from '@chaoswise/cw-mobx';
import idrStore from '../TestingSignoff/store';
import { uniqBy, sortBy } from 'lodash';
import SignOffType from '../TestingSignoff/components/SignoffType';
import Artefact from '../TestingSignoff/components/Artefact';
import CaseId from './components/CaseId';
import { signoffUpdate,getSignOffListByWorkOrderId, submitIDRCseId, signoffInsertBatch, signoffDeleteBatch} from '../api';
import { SIGNOFF_GROUP } from '../constants';
import moment from 'moment';
const IDRSignoff = () => {
  const [tableLoading, setTableLoading] = useState(false);
  const [form] = Form.useForm();
  const { signoffTypeOptions, setSignoffTypeOptions, formData, updateState, orderInfo } = idrStore;
  const crStatus = formData?.crStatus_value || orderInfo?.formData?.crStatus_value;
  const containerRef = useRef();
  const initedRef = useRef(false)
  let accountId = JSON.parse(localStorage.getItem('dosm_loginInfo'))?.user?.accountId || '110';
  let topAccountId = JSON.parse(localStorage.getItem('userConfig'))?.topAccountId || accountId;
  const caseId = Form.useWatch(['IDRSignoff', 0, 'caseId'], form)
  const handleMessage = (event) => {
    const { data } = event;
    switch (data.eventType) {
      case 'onFormMount':
        console.log('Form initialized', data.orderInfo);
        updateState({ orderInfo: data.orderInfo });
        if(data.orderInfo.formData?.crStatus && !initedRef.current){
          getSignoffs(data.orderInfo.formData, data.orderInfo.workOrderId)
          initedRef.current = true
        }
        break;
      case 'onFormValuesChange':
        const tableData = []
        if(data?.values?.IDRsignoff == "271f3a2d5dc04123b5d55c78e586e97b"){
          const newRow = {
            signOffType: ["IDR Signoff"],
            artifact: undefined,
            caseId: undefined
          }
          tableData.push(newRow)
        }
        
        if(crStatus){
          const rowData = form.getFieldValue('IDRSignoff')?.[0]
          if(tableData.length > 0 && !rowData){
            signoffInsertBatch(tableData.map(item => {
              return {
                ...item,
                signOffUserGroup: "[]",
                signOffUser: "[]",
                artifact: JSON.stringify(item.artifact||[]),
                signOffType: JSON.stringify(item.signOffType),
                signOffGroup: SIGNOFF_GROUP.IDR_SIGNOFF,
                topAccountId,
                accountId,
                workOrderId: orderInfo.workOrderId,
                caseId: Array.isArray(item.caseId) ? JSON.stringify(item.caseId) : item.caseId
              }
            })).then(() => {
              getSignoffs()
            })
          }else{
            if(tableData.length > 0 && rowData){
              signoffDeleteBatch([rowData.id]).then(res => {
                getSignoffs()
              })
            }
          }
        }else{
          form.setFieldValue('IDRSignoff', tableData)
        }
        break;
      case 'onOrderCreateSuccess':
        if (!crStatus) {
          const tableData = form.getFieldValue('IDRSignoff')
          const params = tableData.map(item => {
            return {
              ...item,
              status: null,
              signOffUserGroup: "[]",
              signOffUser: "[]",
              artifact: JSON.stringify(item.artifact),
              signOffType: JSON.stringify(item.signOffType),
              signOffGroup: SIGNOFF_GROUP.IDR_SIGNOFF,
              topAccountId,
              accountId,
              caseId: Array.isArray(item.caseId) ? JSON.stringify(item.caseId) : item.caseId,
              workOrderId: data.orderId,
            }
          })
          window.parent.fetch(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/insertBatch`, {
            method: 'POST',
            body: JSON.stringify(params),
            headers: { 'Content-Type': 'application/json' }
          })
        }
        break;
      default:
        console.log('Unhandled event type:', data.eventType);
        break;
    }
  };

  // Get signoffs for the current work order
  const getSignoffs = (formData, workOrderId) => {
    setTableLoading(true);
    const orderId = orderInfo.workOrderId || workOrderId
    const status = crStatus || formData?.crStatus_value
    getSignOffListByWorkOrderId({ workOrderId: orderId, signOffGroup: SIGNOFF_GROUP.IDR_SIGNOFF, })
      .then(res => {
        let data = res?.data?.map(item => ({
          ...item,
          signOffUserGroup: JSON.parse(item.signOffUserGroup),
          signOffUser: JSON.parse(item.signOffUser),
          artifact: JSON.parse(item.artifact),
          signOffType: JSON.parse(item.signOffType),
          caseId: JSON.parse(item.caseId),
        }));
        
        const IDRSignoffData = data?.filter(i => i.signOffGroup === SIGNOFF_GROUP.IDR_SIGNOFF,);
        form.setFieldValue('IDRSignoff', sortBy(IDRSignoffData, 'id'));
        setTableLoading(false);
      })
      .catch(err => {
        setTableLoading(false);
        console.error(err);
      });
  };

  const formDisabled = () => {
    if(orderInfo.createdBy){
      let userInfo = localStorage.getItem('dosm_loginInfo')
      userInfo = JSON.parse(userInfo)
      if(userInfo.user.userId == orderInfo.createdBy){
          return false
      }else{
          return true
      }
    }else{
      return false
    }
  };


  const onValuesChange = (index, key, val) => {
    const tableData = form.getFieldValue('IDRSignoff')
    const rowData = tableData[index]
    if (crStatus) {
      signoffUpdate({
        ...rowData,
        signOffUserGroup: "[]",
        signOffUser: "[]",
        artifact: JSON.stringify(rowData.artifact),
        signOffType: JSON.stringify(rowData.signOffType),
        caseId: JSON.stringify(rowData.caseId),
        status: "APPROVED"
      }).then(res => {
        getSignoffs()
      })
    }
  }

  // Form and window message effects
  useEffect(() => {
    window.parent.postMessage({
      eventType: 'onChildFormInit',
      height: containerRef.current.clientHeight
    }, '*');

    window.formActions = {
      submit: () => {
        return new Promise((resolve, reject) => {
          form.validateFields()
            .then(values => {
              resolve({ values });
            })
            .catch(errors => {
              window.parent.postMessage({ 
                eventType: 'onChildFormValidateError', 
                errors: errors.errorFields 
              }, '*');
              document.querySelector('.ant-form-item-explain-error')?.scrollIntoView({ behavior: 'smooth' });
              const error = errors.errorFields.map(item => ({
                name: item.name,
                messages: item.errors
              }));
              reject(error);
            });
        });
      },
      getFieldsValue: () => {
        return Promise.resolve({
          values: form.getFieldsValue()
        });
      }
    };
  }, []);

  useEffect(() => {
    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [orderInfo, signoffTypeOptions, crStatus]);
  useEffect(() => {
    setSignoffTypeOptions([{label: 'IDR Signoff', value: 'IDR Signoff'}])
  },[])
  const submitCaseId = () => {
    const tableData = form.getFieldValue('IDRSignoff')
    const caseId = tableData[0].caseId
    submitIDRCseId({caseId: Array.isArray(caseId) ? caseId.map(item => item.caseId) : caseId}).then(res => {
      console.log('res', res)
      const caseids = Array.isArray(caseId) ? caseId.map(i => i.caseId) : caseId.split(',')
      const caseidsWithStatus = caseids.map(id => {
        const caseItem = res?.data?.find?.(item => item.CASEID === id)
        if(caseItem){
          // COMPLETIONDSTE is empty, show: Not Approved
          if(!caseItem.COMPLETIONDATE){
            return {
              caseId: id,
              status: 'FAILD',
              showStatus: 'Not Approved'
            }
          }else{
            const currentDate = moment()
            const COMPLETIONDATE = moment(caseItem.COMPLETIONDATE)
            const monthsDiff = currentDate.diff(COMPLETIONDATE, 'months'); 
            if(monthsDiff > 6){
              return {
                caseId: id,
                status: 'FAILD',
                showStatus: 'Signoff Exceed 6 Months'
              }
            }else{
              return {
                caseId: id,
                status: 'VALID',
                showStatus: 'Signoff Valid'
              }
            }
          }
        }else{
          return {
            caseId: id,
            status: 'FAILD',
            showStatus: 'Signoff not Found'
          }
        }
      })
      tableData[0].caseId = caseidsWithStatus
      form.setFieldValue('IDRSignoff', tableData)
      form.validateFields([['IDRSignoff', 0, 'caseId']],{force: true})
      if(crStatus){
        onValuesChange(0)
      }
    })
  }
  return (
    <div ref={containerRef}>
      <Form form={form} name="signoff">
        <Form.List name="IDRSignoff">
          {(fields, { add, remove }) => (
            <>
              <CWTable
                loading={tableLoading}
                dataSource={fields?.map((i) => ({ ...i, remove, form, signoffTypeOptions: signoffTypeOptions, onValuesChange }))}
                pagination={false}
                rowKey="key"
                scroll={{ x: 1200 }}
                columns={[
                  {
                    title: <span><span style={{color: '#f5222d'}}>*</span>Signoff Type</span>,
                    key: 'signOffType',
                    width: '200px',
                    render: (_, row) => (
                      <Form.Item 
                        name={[row.name, 'signOffType']} 
                        rules={[{ required: true, message: 'Please select Signoff Type' }]}
                      >
                        <SignOffType row={row} disabled={true} />
                      </Form.Item>
                    )
                  },
                  {
                    title: <span><span style={{color: '#f5222d'}}>*</span>Artefact</span>,
                    key: 'artifact',
                    width: '200px',
                    render: (_, row) => (
                      <Form.Item 
                        name={[row.name, 'artifact']} 
                        rules={[{ required: true, message: 'Please upload artefact' }]}
                      >
                        <Artefact disabled={formDisabled()} row={row} />
                      </Form.Item>
                    )
                  },
                  {
                    title: <span><span style={{color: '#f5222d'}}>*</span>Case ID</span>,
                    key: 'caseId',
                    render: (_, row) => {
                      return <Form.Item 
                        name={[row.name, 'caseId']} 
                        validateFirst={true}
                        rules={[
                          { required: true, message: 'Please Enter Case ID' },
                          {validator: (rule, value, callback) => {
                            console.log('value', value);
                            
                            if(Array.isArray(value)){
                              return callback()
                            }else{
                              return callback('Please submit the IDR signoff first.')
                            }
                          }}
                        ]}
                      >
                        <CaseId disabled={formDisabled()} row={row} />
                      </Form.Item>
                    }
                  },
                  {
                    title: "Actions",
                    key: 'actions',
                    width: '100px',
                    render: (_, row) => {
                      const tableData = form.getFieldValue('IDRSignoff');
                      const rowData = tableData[row.name] || {}
                      if(Array.isArray(rowData.caseId)){
                        return <Button type="primary" onClick={submitCaseId}>
                          Refresh
                        </Button>
                      }
                      return (
                        <Space>
                          <Button type="primary" onClick={submitCaseId} disabled={!rowData.caseId}>
                            Submit
                          </Button>
                        </Space>
                      );
                    }
                  }
                ]}
              />
            </>
          )}
        </Form.List>
      </Form>
      <style jsx>{`
        :global(.ant-form-item-with-help){
          margin-bottom: 20px;
        }
      `}</style>
    </div>
  );
};

export default observer(IDRSignoff);
