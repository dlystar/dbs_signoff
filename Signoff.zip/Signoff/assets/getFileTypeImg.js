import svg7z from './7z.svg'
import svgavi from './avi.svg'
import svgbmp from './bmp.svg'
import svgcsv from './csv.svg'
import svgdocx from './docx.svg'
import svggif from './gif.svg'
import svggz from './gz.svg'
import svgjar from './jar.svg'
import svgjpg from './jpg.svg'
import svgmov from './mov.svg'
import svgmp3 from './mp3.svg'
import svgmp4 from './mp4.svg'
import svgmsg from './msg.svg'
import svgpdf from './pdf.svg'
import svgpng from './png.svg'
import svgpptx from './pptx.svg'
import svgps1 from './ps1.svg'
import svgpy from './py.svg'
import svgrar from './rar.svg'
import svgrmvb from './rmvb.svg'
import svgsh from './sh.svg'
import svgtar from './tar.svg'
import svgtiff from './tiff.svg'
import svgtxt from './txt.svg'
import svgwav from './wav.svg'
import svgwebp from './webp.svg'
import svgwma from './wma.svg'
import svgwmv from './wmv.svg'
import svgxlsm from './xlsm.svg'
import svgxmind from './xmind.svg'
import svgzip from './zip.svg'
export default (type) => {
    const fielTypes = {
        '7z': svg7z,
        'avi': svgavi,
        'bmp': svgbmp,
        'csv': svgcsv,
        'docx': svgdocx,
        'doc': svgdocx,
        'gif': svggif,
        'gz': svggz,
        'jar': svgjar,
        'jpg': svgjpg,
        'jpeg': svgjpg,
        'mov': svgmov,
        'mp3': svgmp3,
        'mp4': svgmp4,
        'msg': svgmsg,
        'pdf': svgpdf,
        'png': svgpng,
        'pptx': svgpptx,
        'ppt': svgpptx,
        'ps1': svgps1,
        'py': svgpy,
        'rar': svgrar,
        'rmvb': svgrmvb,
        'sh': svgsh,
        'tar': svgtar,
        'tiff': svgtiff,
        'txt': svgtxt,
        'wav': svgwav,
        'webp': svgwebp,
        'wma': svgwma,
        'wmv': svgwmv,
        'xlsm': svgxlsm,
        'xls': svgxlsm,
        'xlsx': svgxlsm,
        'xmind': svgxmind,
        'zip': svgzip,
    }
    return <img src={fielTypes[type]} />
}