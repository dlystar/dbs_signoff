import React, { useState, useEffect } from "react";
import { UploadOutlined, CloudUploadOutlined, EyeOutlined, DownloadOutlined, DeleteOutlined } from '@ant-design/icons';
import { Button, Upload, message, Modal, TooltipText, Tooltip } from '@chaoswise/ui';
import {uploadFileList, reviewFile, downloadFile, bulkDownloadFile} from '../../api'
import getFileTypeImg from '../../assets/getFileTypeImg'
// eslint-disable-next-line import/no-anonymous-default-export
export default ({ value = [], onChange, row, disabled, ...props }) => {
    const {form, onValuesChange} = row
    const [fileList, setFileList] = useState(value)
    const [imageList, setImageList] = useState([]);
    const [currentFileList, setCurrentFileList] = useState([])
    const [listMark, setListMark] = useState({fileList,imageList});
    const [uploading, setUploading] = useState(false)
    const [percent, setPercent] = useState(0);
    const [visible, setVisible] = useState(false);
    const [viewVisible, setViewVisible] = useState(false)
    const [currentViewFile, setCurrentViewFile] = useState({})
    const uploadFileSize = 15;
    const { enumAcceptType } = window.DOSM_CONFIG
    const _accept = enumAcceptType.split(',').map(i => i.replace('.',''))
    const handleChange = (val) => {
        onChange(val)
        onValuesChange(row.name, 'artifact', val)
    }
    const convertFileSize = (limit) => {
        let size = '';
        if (limit < 1024) {
            //小于1KB，则转化成B
            size = limit.toFixed(2) + 'B';
        } else if (limit < 1024 * 1024) {
            //小于1MB，则转化成KB
            size = (limit / 1024).toFixed(2) + 'KB';
        } else if (limit < 1024 * 1024 * 1024) {
            //小于1GB，则转化成MB
            size = (limit / (1024 * 1024)).toFixed(2) + 'MB';
        } else {
            //其他转化成GB
            size = (limit / (1024 * 1024 * 1024)).toFixed(2) + 'GB';
        }

        let sizeStr = size + ''; //转成字符串
        let index = sizeStr.indexOf('.'); //获取小数点处的索引
        let dou = sizeStr.substr(index + 1, 2); //获取小数点后两位的值
        if (dou == '00') {
            //判断后两位是否为00，如果是则删除00
            return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
        }
        return size;
    };
    const beforeUpload = (file, fileLists) => {
        let typeList = [];
        fileLists?.map((item) => {
            let { type, size } = item;
            typeList?.push(type);
        });

        const checkSizeIsNull = (list) => {
            let sizeList = [];
            list?.map((item) => {
                let { type, size } = item;
                sizeList?.push(size);
            });

            return sizeList?.filter((item) => {
                return item === 0;
            })?.length;
        };

        const checkSizeIsBig = (list) => {
            return list?.filter((item) => {
                return item?.size > uploadFileSize * 1048576;
            })?.length;
        };

        let uploadList = [...fileLists];

        if (checkSizeIsNull(uploadList)) {
            uploadList?.forEach((item, index) => {
                if (item?.size == 0) {
                    delete uploadList[index];
                }
            });

            let arr = [];
            uploadList?.forEach((item) => {
                if (item) {
                    arr?.push(item);
                }
            });
            uploadList = arr;

            window.parent.prompt.error('You are not allowed to upload an empty file');

            if (!uploadList?.length) {
                return false;
            }
        }

        if (checkSizeIsBig(uploadList)) {
            uploadList?.forEach((item, index) => {
                if (item?.size > uploadFileSize * 1048576) {
                    //限制大小
                    delete uploadList[index];
                }
            });

            let arr = [];
            uploadList?.forEach((item) => {
                if (item) {
                    arr?.push(item);
                }
            });
            uploadList = arr;
            window.parent.prompt.error(`Max size: ${uploadFileSize}MB`);
            if (!uploadList?.length) {
                return false;
            }
        }

        const checkSuffix = (list) => {
            return list?.filter((file) => {
                const suffix = file.name
                    .substring(file.name.lastIndexOf('.') + 1, file.name.length)
                    .toLowerCase();
                return !_accept.includes(suffix);
            })?.length;
        };
        if (checkSuffix(uploadList)) {
            uploadList?.forEach((file, index) => {
                const suffix = file.name
                    .substring(file.name.lastIndexOf('.') + 1, file.name.length)
                    .toLowerCase();
                if (!_accept.includes(suffix)) {
                    delete uploadList[index];
                }
            });
            let arr = [];
            uploadList?.forEach((item) => {
                if (item) {
                    arr?.push(item);
                }
            });
            uploadList = arr;
            window.parent.prompt.error('File in this format is not supported.');
            if (!uploadList?.length) {
                return false;
            }
        }

        let _imgList = [];
        let _fileList = [];
        uploadList?.forEach((item) => {
            if (item.type?.startsWith('image')) {
                _imgList?.push({
                    ...item,
                    fileName: item.name,
                    type: 'img',
                });
            }
            // 无论什么类型的文件都将放进fileList中
            _fileList?.push({
                ...item,
                name: item.name,
                size: convertFileSize(item.size),
                load: true,
                type: item.type?.startsWith('image') ? 'img' : null,
            });
        });
        // setListMark({
        //     fileList,
        //     imageList,
        // });
        setFileList([...(fileList || []), ...(_fileList || [])]);
        setImageList([...(imageList || []), ...(_imgList || [])])
        setCurrentFileList(uploadList);
    };
    const cb = (event) => {
        setPercent(parseInt(((event.loaded / event.total) * 100).toFixed(0)));
    };
    const customRequest = ({ file, onProgress, onSuccess, onError, ...rest }) => {
        setUploading(true);
        uploadFileList({
            files: currentFileList
        }, cb).then(
            (res) => {
                console.log('res', res);
                
                const { data } = res;
                const { failFile, fileVoList } = data;
                const fileListNew = fileVoList.map(item => {
                    return {
                        id: item.id,
                        load: true,
                        name: item.fileName,
                        size: item.fileSize,
                        thype: null,
                        uid: item.id,
                        uploadUserName: item.uploadUserName,
                        url: item.url
                    }
                })
                handleChange([...(value||[]), ...(fileListNew||[])])
            },
            (err) => {
                window.parent.prompt.error(
                    err?.msg ||
                    'Upload timeout caused by poor network or large file.'
                );
                setFileList(listMark.fileList || []);
                setImageList(listMark.imageList || []);
                setUploading(false);
            }
        );
    }
    const viewFile = (file) => {
        setViewVisible(true)
        setCurrentViewFile(file)
    }
    const download = (file) => {
        downloadFile(file.id, file.name)
    }
    const bulkDownload = () => {
        const ids = value.map(i => i.id)
        bulkDownloadFile(ids, 'Artefact.zip')
    }
    const deleteFile = (file, listType) => {
        const _value = JSON.parse(JSON.stringify(value))
        _value.splice(_value.findIndex(i => i.id === file.id), 1)
        handleChange(_value)
    }
    const renderFileItem = (fileItem, listType) => {
        return <div className="file_item" style={{display: 'flex', alignItems: 'center', paddingLeft: 10}}>
            <div className="file_name" style={{width: 500}}><TooltipText ellipsisPosition="center"><a onClick={() => viewFile(fileItem)}>{fileItem.name}</a></TooltipText></div>
            <div className="file_oprate" style={{width: 100, marginLeft: 20}}>
                {/* <Button style={{border: 'none', background: 'transparent'}} onClick={() => viewFile(fileItem)}><EyeOutlined /></Button> */}
                <Button style={{border: 'none', background: 'transparent'}} onClick={() => download(fileItem)}><DownloadOutlined /></Button>
                <Button style={{border: 'none', background: 'transparent'}} onClick={() => deleteFile(fileItem, listType)}><DeleteOutlined /></Button>
            </div>
        </div>
    }
    const renderFileOuter = (fileItem) => {
        const fileType = fileItem.name.split('.')[fileItem.name.split('.').length - 1]
        return <Tooltip title={fileItem.name}>{getFileTypeImg(fileType.toLowerCase())}</Tooltip>
    }
    const hasFile = () => {
        return value?.length > 0
    }
    const getContainer = () => {
        const {inIframe} = window.DOSM_CUSTOM_DBS.signoff
        if(inIframe){
            return window.parent?.document?.body
        }else{
            return document.body
        }
    }
    return <div>
        <Button disabled={disabled && !hasFile()} onClick={() => setVisible(true)} style={{background: '#f0f1f4', border: 'none'}}>
            {<UploadOutlined style={{marginRight: 5}} />}
            {
                hasFile() ? 
                <div className="files" style={{maxWidth: 200}}>
                        {value?.map(item => renderFileOuter(item))}
                        {/* {value?.result?.imageList?.map(item => renderFileOuter(item))} */}
                </div>
                : 'Upload'
            }
        </Button>
        <Modal visible={visible} footer={null} maskClosable closeIcon={false} onCancel={() => setVisible(false)} getContainer={getContainer}>
            <div className="upload_modal" style={{marginTop: 20}}>
                <style>{`.upload_modal .file_item:hover{background: #e5f6ff;}`}</style>
                {
                    !disabled && <Upload.Dragger
                        listType='text'
                        fileList={value||[]}
                        beforeUpload={(file, fileList) => beforeUpload(file, fileList)}
                        customRequest={customRequest}
                        // accept={newfileTypeArray?.join(',')}
                        multiple={true}
                        showUploadList={false}
                    >
                        <div style={{padding: '20px 0px', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                            <CloudUploadOutlined style={{fontSize: 20, marginRight: 20, color: '#1980ff'}} />Click or drag the file to this area
                        </div>
                    </Upload.Dragger>
                }
                <div style={{textAlign: 'right', margin: '5px 0px'}}>
                    {
                        (value?.length > 0) &&
                        <Button onClick={bulkDownload} type="link" style={{border: 'none'}}><DownloadOutlined />Bulk Download</Button>
                    }
                </div>
                <div className="files">
                    {value && value?.map?.(item => renderFileItem(item, 'fileList'))}
                    {/* {value?.result?.imageList?.map(item => renderFileItem(item, 'imageList'))} */}
                </div>
            </div>
        </Modal>
        <Modal 
            visible={viewVisible} 
            title={<div style={{display: 'flex', justifyContent: 'space-between'}}>
                <div>{currentViewFile.name}</div>
                <Button style={{marginRight: 50}}><DownloadOutlined />Download</Button>
            </div>} 
            width="98%" 
            style={{top: 20}}
            footer={null} 
            maskClosable
            onCancel={() => setViewVisible(false)}
            getContainer={getContainer}
        >
            <iframe style={{width: '100%', height: 600}} src={reviewFile(currentViewFile.id)}></iframe>
        </Modal>
    </div>
}