import { useState, useEffect, useMemo, useRef } from 'react'
import {CWSelect, Form4 as Form} from '@chaoswise/ui'
import {getUsersByGroupId} from '../../api'
import usePopUpStyle from '../../useDropDwonStyle'
// eslint-disable-next-line import/no-anonymous-default-export
export default ({value, onChange, row, disabled, multiple, ...props}) => {
    const {form, onValuesChange} = row
    const key = props.id.split('_').splice(1)
    key.splice(2,1,'signOffUserGroup')
    const signOffUserGroup = Form.useWatch(key, form)
    const [list, setList] = useState([])
    const selectRef = useRef(null)
    const {open, setOpen} = usePopUpStyle(selectRef, props.id)
    useEffect(() => {
        if(signOffUserGroup?.[0]?.groupId){
            getUsersByGroupId(signOffUserGroup?.[0]?.groupId).then(res =>{
                setList(res.data.userList.map(item => {
                    return {
                        label: `${item.name}(${item.userAlias})`,
                        value: `${item.id}`
                    }
                }))
            })
        }else{
            setList([])
        }
    },[signOffUserGroup])
    const getPopupContainer = (e) => {
        const {inIframe} = window.DOSM_CUSTOM_DBS.signoff
        if(inIframe){
            return window.parent?.document?.body
        }else{
            return document.body
        }
    }
    return <div ref={selectRef}>
        <CWSelect 
            value={multiple ? value?.map(i => i.userId) :value?.[0]?.userId} 
            onChange={(val, option) => {
                console.log(val, option);
                let _val = []
                if(Array.isArray(val)){
                    _val = val.map(item => {
                        return {
                            userName: option.find(i => i.key == item).label,
                            userId: item,
                            groupName: null,
                            groupId: null
                        }
                    })
                }else{
                    _val = [
                        {
                            userName: option.props.label,
                            userId: val,
                            groupName: null,
                            groupId: null
                        }
                    ]
                }
                onChange(_val)
                onValuesChange(row.name, 'signOffUser', _val)
                setOpen(false)
            }} 
            getPopupContainer={getPopupContainer}
            dropdownClassName={props.id}
            onDropdownVisibleChange={(open) => setOpen(open)}
            open={open}
            disabled={disabled}
            placeholder="Please select"
            mode={multiple ? 'multiple' : undefined}
            showCheckbox={multiple ? true : false}
        >
            {
                list.map(item => <CWSelect.Option value={item.value} key={item.value} label={item.label}>{item.label}</CWSelect.Option>)
            }
        </CWSelect>
    </div>
}