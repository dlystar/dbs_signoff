import { useState, useEffect, useMemo, useRef } from 'react'
import {Select, Form4 as Form} from '@chaoswise/ui'
import {getUserGroupInfoByIds} from '../../api'
import DoVisibleRange from '@/components/DoVisibleRange'
import useDropDwonStyle from '../../useDropDwonStyle'
// eslint-disable-next-line import/no-anonymous-default-export
export default ({value, onChange, row, disabled, ...props}) => {
    const {uatGroupIds, nUatGroupIds} = window.DOSM_CUSTOM_DBS.signoff.testingSignoff
    const {form, onValuesChange} = row
    const key = props.id.split('_').splice(1)
    key.splice(2,1,'signOffType')
    const signOffType = Form.useWatch(key, form)
    const [uatList, setUatList] = useState([])
    const [nUatlist, setNUatList] = useState([])
    const initedRef = useRef(false)
    const selectRef = useRef()
    const {open, setOpen} = useDropDwonStyle(selectRef, props.id)
    useEffect(() => {
        Promise.all([getUserGroupInfoByIds({groupIds: uatGroupIds.join(',')}), getUserGroupInfoByIds({groupIds: nUatGroupIds.join(',')})]).then(res => {
            console.log(res)
            const [groups1, groups2] = res
            setUatList(groups1.data.map(i => ({label: i.groupName, value: i.groupId})))
            setNUatList(groups2.data.map(i => ({label: i.groupName, value: i.groupId})))
        })
        initedRef.current = true
    },[])
    const groupIds = useMemo(() => {
        if(signOffType && signOffType.includes('UAT')){
            return uatGroupIds
        }else{
            return nUatGroupIds
        }
    },[signOffType])
    const handleChange = (val) => {
        console.log('val', val)
        // group类型变更，清空user
        const key = props.id.split('_').splice(1)
        key.splice(2,1,'signOffUser')
        const namePath = key.map(i => isNaN(i) ? i : Number(i))
        form.setFieldValue(namePath, undefined)
        onChange(val)
        onValuesChange(row.name, 'signOffUserGroup', val)
    }
    const getPopupContainer = (e) => {
        const {inIframe} = window.DOSM_CUSTOM_DBS.signoff
        if(inIframe){
            return window.parent?.document?.body
        }else{
            return document.body
        }
    }
    console.log('groupIds', groupIds);
    
    return <div ref={selectRef}>
        <DoVisibleRange 
            types={['group']}
            crossTenant={true}
            userStatus={false}
            group={{
                multiple: false,
                visibleGroupIds: groupIds,
                onlyGroup: true,
            }}
            value={value}
            onChange={handleChange}
            getPopupContainer={getPopupContainer}
            dropDownOverlayClassName={props.id}
            setOpen={setOpen}
            disabled={disabled}
            placeholder="Please select"
        />
    </div>
}