import React, { useEffect, useMemo, useRef, useState } from "react";
import {CWTable, Form4 as Form, Space, Button, Modal, Checkbox, Input} from '@chaoswise/ui'
import testingSignoffStore from './store';
import { observer } from '@chaoswise/cw-mobx';
import Status from './components/Status';
import SignOffType from './components/SignoffType';
import RejectionReason from './components/RejectionReason';
import SignOffUserGroup from '../components/Group'
import SignOffUser from './components/User'
import Artefact from './components/Artefact'
import {DeleteOutlined} from '@ant-design/icons';
import uniqBy from 'lodash-es/uniqBy'
import sortBy from 'lodash-es/sortBy'
import {signoffInsertBatch, signoffUpdate, signoffApproved, signoffRejected, signoffSendEmail, getSignOffListByWorkOrderId, signoffStatus, signoffDeleteBatch} from '../api'
import { getFlatSchema } from '@/pages/BusinessSetting/ProcessManagement/CreateNew/FormDesign/FormEngine/FormRender/util/handleSchema';
import { PlusOutlined } from '@ant-design/icons';
import { SIGNOFF_GROUP } from '../constants';
import { helper } from '@/utils/T';
const Signoff = () => {
    const [tableLoading, setTableLoading] = useState(false)
    const [form] = Form.useForm();
    window.form = form
    const {signoffTypeOptions, setSignoffTypeOptions, formData, updateState, orderInfo} = testingSignoffStore
    const crStatus = formData?.crStatus_value || orderInfo?.formData?.crStatus_value
    const containerRef = useRef()
    const initedRef = useRef(false)
    let accountId = JSON.parse(localStorage.getItem('dosm_loginInfo'))?.user?.accountId || '110';
    let topAccountId = JSON.parse(localStorage.getItem('userConfig'))?.topAccountId || accountId;
    // Form changes will reset the signoff approval status
    const shouldResetSignoff = (index, key, val) => {
        const tableData = form.getFieldValue('testingSignoff')
        const rowData = tableData[index]
        // when crStatus is new，change User field
        // when crStatus is new，change artefact field
        if(crStatus && rowData.status != 'WAITSEND'){
            if(key == 'signOffUser' && val){
                return true
            }
            if(key == 'artifact' && val){
                return true
            }
            if(key == 'signOffType' && val){
                return true
            }
        }
        return false
    }
    const arrayIsEqual = (arr1, arr2) => {
        if(!Array.isArray(arr1) || !Array.isArray(arr2)) return false
        return JSON.stringify(arr1) == JSON.stringify(arr2)
    }

    const {signoffTypes} = window.DOSM_CUSTOM_DBS.signoff.testingSignoff
    const tableHasFormData = (key, value, tableData) => {
        return !!tableData.find(item => item[key]?.includes(value))
    }
    const newRow = (signoffTypeValue)=> {
        const rowData = {
            status: "WAITSEND",
            signOffType: signoffTypeValue ? [signoffTypeValue] : undefined,
            signOffUserGroup: undefined,
            signOffUser: undefined,
            artifact: undefined,
            rejectionReason: undefined
        }
        return rowData
    }    
    const fieldChange = helper.debounce((formData, _tableData, _orderInfo, onlyUpdateOptions) => {
        const flatSchame = getFlatSchema(orderInfo?.schema || _orderInfo?.schema)
        const _signoffTypeOptions = JSON.parse(JSON.stringify(signoffTypeOptions))
        const tableData = JSON.parse(JSON.stringify(_tableData || []))
        let newRows = []
        let deleteRows = []
        signoffTypes.forEach(signoffType => {
            if(flatSchame[signoffType.formKey]){
                const {key} = flatSchame[signoffType.formKey]
                const title = signoffType.signoffType
                const name = key
                // Check if the form data matches the signoff condition value and if the table data does not already have a row with the same signoff type
                if(formData[name] && signoffType.conditionValue.includes(formData[name]) && !tableHasFormData('signOffType', title, tableData)){
                    tableData.push(newRow(title))
                    newRows.push(newRow(title))
                    _signoffTypeOptions.push({label: title, value: title})
                }
                // Check if the form data does not match the signoff condition value and if the table data already has a row with the same signoff type
                if(formData[name] && !signoffType.conditionValue.includes(formData[name]) && tableHasFormData('signOffType', title, tableData)){
                    const index = tableData.findIndex(item => arrayIsEqual(item.signOffType, [title]))
                    if(index > -1) {
                        let deleteRow = tableData.splice(index, 1)
                        deleteRows = deleteRows.concat(deleteRow.filter(i => i.id))
                    }
                    const _index = _signoffTypeOptions.findIndex(i => i.value === title)
                    if(_index > -1) _signoffTypeOptions.splice(_index, 1);
                }
            }
        })

        setSignoffTypeOptions(uniqBy(_signoffTypeOptions, 'value'))
        if(!onlyUpdateOptions){
            if(!arrayIsEqual(_tableData, tableData)){
                if(formData.crStatus || crStatus){
                    if (deleteRows.length > 0) {
                        signoffDeleteBatch(deleteRows.map(item => item.id)).then(res => {
                            getSignoffs()
                        })
                    }
                    if (newRows.length > 0) {
                        signoffInsertBatch(newRows.map(item => {
                            return {
                                ...item,
                                signOffUserGroup: JSON.stringify(item.signOffUserGroup),
                                signOffUser: JSON.stringify(item.signOffUser),
                                artifact: JSON.stringify(item.artifact),
                                signOffType: JSON.stringify(item.signOffType),
                                signOffGroup: SIGNOFF_GROUP.TESTING_SIGNOFF,
                                topAccountId,
                                accountId,
                                workOrderId: orderInfo.workOrderId
                            }
                        })).then(() => {
                            getSignoffs()
                        })
                    }
                }
                setTimeout(() => {
                    form.setFieldValue('testingSignoff', tableData)
                },60)
            }
        }
    },300)
    const handleMessage = (event) => {
        const {data} = event
        switch (data.eventType) {
            case 'onFormMount':
                updateState({orderInfo: data.orderInfo})
                fieldChange(data.orderInfo.formData, testingSignoff, data.orderInfo, true)
                if(data.orderInfo.formData?.crStatus && !initedRef.current){
                    setTimeout(() => {
                        getSignoffs(data.orderInfo.formData, data.orderInfo.workOrderId)
                    },1000)
                    initedRef.current = true
                }
                break;
            case 'onFormValuesChange':
                const testingSignoff = form.getFieldValue('testingSignoff')
                fieldChange(data.values, testingSignoff)
                updateState({formData: data.values})
                break;
            case 'onOrderCreateSuccess':
                // when crStatus is empty (means create order)
                if(!crStatus){
                    const tableData = form.getFieldValue('testingSignoff')
                    const params = tableData.map(item => {
                        return {
                            ...item,
                            signOffUserGroup: JSON.stringify(item.signOffUserGroup),
                            signOffUser: JSON.stringify(item.signOffUser),
                            artifact: JSON.stringify(item.artifact),
                            signOffType: JSON.stringify(item.signOffType),
                            signOffGroup: SIGNOFF_GROUP.TESTING_SIGNOFF,
                            topAccountId,
                            accountId,
                            workOrderId: data.orderId
                        }
                    })
                    window.parent.fetch(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/insertBatch`,{
                        method: 'POST',
                        body: JSON.stringify(params),
                        headers: { 'Content-Type': 'application/json' }
                    })
                }
                break;
            default:
                console.log('Unhandled event type:', data.eventType);
                break;
        }
    }
    const onValuesChange = (index, key, val) => {
        const tableData = form.getFieldValue('testingSignoff')
        const rowData = tableData[index]
        if(crStatus){
            signoffUpdate({
                ...rowData, 
                signOffUserGroup: JSON.stringify(rowData.signOffUserGroup),
                signOffUser: JSON.stringify(rowData.signOffUser),
                artifact: JSON.stringify(rowData.artifact),
                signOffType: JSON.stringify(rowData.signOffType),
            }).then(res => {
                if(shouldResetSignoff(index, key, val)){
                    signoffStatus({signOffId: rowData.id, status: 'WAITSEND'}).then(res => {
                        getSignoffs()
                    }).catch(err => {
                        window.parent.prompt.error(err.msg)
                    })
                }else{
                    getSignoffs()
                }
            })
        }
    }
    // 发送
    const sendEmail = (rowNum) => {
        const tableData = form.getFieldValue('testingSignoff')
        const rowData = tableData[rowNum]
        let clickable = false
        const onChange = (e) => {
            clickable = e.target.checked
            if(e.target.checked){
                window.parent.sendEmail_button.removeAttribute('disabled')
            }else{
                window.parent.sendEmail_button.setAttribute('disabled', true)
            }
        }
        setTimeout(() => {
            window.parent.sendEmail_button.setAttribute('disabled', true)
        },60)
        Modal.confirm({
            title: 'Delarrtion',
            content: <span><Checkbox onChange={onChange} style={{marginRight: 10}} />I am fully responsible & accountable for all the artefacts uploaded and attest that it does not contain any customer, sensitive, or Pll data.</span>,
            okButtonProps: {id: 'sendEmail_button'},
            getContainer(){
                const {inIframe} = window.DOSM_CUSTOM_DBS.signoff
                if(inIframe){
                    return window.parent?.document?.body
                }else{
                    return document.body
                }
            },
            onOk(){
                return signoffSendEmail({signOffId: rowData.id}).then(res => {
                    window.parent.prompt.success('Successfully send')
                    getSignoffs()
                }).catch(err => {
                    window.parent.prompt.error(err.msg)
                })
            },
        })
    }
    const approval = (rowNum) => {
        const tableData = form.getFieldValue('testingSignoff')
        const rowData = tableData[rowNum]
        signoffApproved({signOffId: rowData.id}).then(res => {
            window.parent.prompt.success('Approved')
            getSignoffs()
        }).catch(err => {
            window.parent.prompt.error(err.msg)
        })
    }
    const reject = (rowNum) => {
        const tableData = form.getFieldValue('testingSignoff')
        const rowData = tableData[rowNum]
        let rejectionReason = ''
        const onChange = (e) => {
            rejectionReason = e.target.value
        }
        Modal.confirm({
            title: 'Rejection Reason',
            icon: null,
            content: <div><Input.TextArea onChange={onChange} /></div>,
            getContainer(){
                const {inIframe} = window.DOSM_CUSTOM_DBS.signoff
                if(inIframe){
                    return window.parent?.document?.body
                }else{
                    return document.body
                }
            },
            onOk(){
                return signoffRejected({signOffId: rowData.id, rejectionReason: rejectionReason}).then(res => {
                    window.parent.prompt.success('Rejected')
                    getSignoffs()
                }).catch(err => {
                    window.parent.prompt.error(err.msg)
                })      
            },
        })
    }
    useEffect(() => {
        window.parent.postMessage({
            eventType: 'onChildFormInit',
            height: containerRef.current.clientHeight
        }, '*');
        window.formActions = {
            submit: () => {
                return new Promise((resolve, reject) => {
                    form.validateFields().then(values =>{
                        console.log('values', values);
                        const {testingSignoff} = values
                        const inputTypes = testingSignoff?.map(item => item.signOffType)?.flat() || []
                        let needTypes = []
                        signoffTypes.forEach(item => {
                            if(item.conditionValue.includes(formData[item.formKey])){
                                needTypes.push(item.signoffType)
                            }
                        })
                        let notTypes = []
                        needTypes.forEach(item => {
                            if(!inputTypes.includes(item)){
                                notTypes.push(item)
                            }
                        })
                        if(notTypes.length > 0){
                            const error = [
                                {
                                    name: 'testingSignoff',
                                    messages: ''
                                }
                            ]
                            reject(error)
                            window.parent.prompt.error(`You need to get ${notTypes.join(',')} Signoff to submit CR.`)
                        }else{
                            resolve({ values })
                        }
                    }).catch(errors =>{
                        window.parent.postMessage({ eventType: 'onChildFormValidateError', errors: errors.errorFields }, '*')
                        document.querySelector('.ant-form-item-explain-error').scrollIntoView({ behavior: 'smooth' })
                        const error = errors.errorFields.map(item => {
                            return {
                                name: item.name,
                                messages: item.errors
                            }
                        })
                        return reject(error)
                    })
                })
            },
            getFieldsValue: () => {
                return Promise.resolve({
                    values: form.getFieldsValue()
                })
            }
        }
    },[])
    // message
    useEffect(() => {
        window.addEventListener('message', handleMessage);
        return () => {
            window.removeEventListener('message', handleMessage);
        };
    },[orderInfo, signoffTypeOptions, crStatus])

    const getSignoffs = (formData, workOrderId) => {
        setTableLoading(true)
        const orderId = orderInfo.workOrderId || workOrderId
        const status = crStatus || formData?.crStatus_value
        getSignOffListByWorkOrderId({workOrderId: orderId, signOffGroup: SIGNOFF_GROUP.TESTING_SIGNOFF}).then(res => {
            res = res?.data?.map(item => {
                return {
                    ...item,
                    signOffUserGroup: JSON.parse(item.signOffUserGroup),
                    signOffUser: JSON.parse(item.signOffUser),
                    artifact: JSON.parse(item.artifact),
                    signOffType: JSON.parse(item.signOffType),
                }
            })
            const testingSignoffData = res?.filter(i => i.signOffGroup === SIGNOFF_GROUP.TESTING_SIGNOFF)
            form.setFieldValue('testingSignoff', sortBy(testingSignoffData, 'id'))
            let typeOptions = []
            testingSignoffData.forEach(i => {
                typeOptions = typeOptions.concat(i.signOffType || [])
            })
            console.log('--------', uniqBy(typeOptions.map(i => ({label: i, value: i})), 'value'));
            
            // setSignoffTypeOptions(uniqBy(typeOptions.map(i => ({label: i, value: i})), 'value'))
            setTableLoading(false)
        }).catch(err => {
            setTableLoading(false)
        })
    }
    const formDisabled = () => {
        if(orderInfo.createdBy){
            let userInfo = localStorage.getItem('dosm_loginInfo')
            userInfo = JSON.parse(userInfo)
            if(userInfo.user.userId == orderInfo.createdBy){
                return false
            }else{
                return true
            }
        }else{
            return false
        }
    }
    const addRecord = () => {
        const tableData = form.getFieldValue('testingSignoff') || []
        if(!crStatus){
            tableData.push(newRow())
            form.setFieldValue('testingSignoff', tableData)
        }else{
            const rowData = {
                status: "WAITSEND",
                signOffType: JSON.stringify([signoffTypeOptions[0].value]),
                signOffUserGroup: undefined,
                signOffUser: undefined,
                artifact: undefined,
                signOffGroup: 'TestingSignoff'
            }
            signoffInsertBatch([{...rowData, workOrderId: orderInfo.workOrderId}]).then(res => {
                getSignoffs()
            })
        }
    }
    const removeRecord = (row) => {
        if(!crStatus){
            row.remove(row.name)
        }else{
            const tableData = form.getFieldValue('testingSignoff') || []
            const deleteRow = tableData[Number(row.name)]
            signoffDeleteBatch([deleteRow.id]).then(res => {
                getSignoffs()
            })
        }
    }
    const showAdd = () => {
        let userInfo = localStorage.getItem('dosm_loginInfo')
        userInfo = JSON.parse(userInfo)
        const currentUser = userInfo.user.userId
        // const tableData = form.getFieldValue('testingSignoff') || []
        return (!crStatus || (crStatus == 'New' && currentUser == orderInfo.createdBy)) && signoffTypeOptions.length > 0
    }
    return <div className="testingSignoff" ref={containerRef}>
        <Form form={form} name="signoff">
            <Form.List name="testingSignoff">
                {(fields, { add, remove }, { errors }) => {
                    return <CWTable
                        loading={tableLoading}
                        scroll={{ x: 1200 }}
                        columns={[
                            {
                                title: "Status",
                                key: 'status',
                                index: 'status',
                                width: '100px',
                                render(text, row){
                                    return <Form.Item name={[row.name, 'status']}>
                                        <Status row={row} disabled={formDisabled()} />
                                    </Form.Item>
                                }
                            },
                            {
                                title: <span><span style={{color: '#f5222d'}}>*</span>Signoff Type</span>,
                                key: 'signOffType',
                                index: 'signOffType',
                                width: '200px',
                                render(text, row){
                                    return <Form.Item name={[row.name, 'signOffType']} rules={[{ required: true, message: 'Please select Signoff Type' }]}>
                                        <SignOffType row={row} disabled={formDisabled()} />
                                    </Form.Item>
                                }
                            },
                            {
                                title: <span><span style={{color: '#f5222d'}}>*</span>Group</span>,
                                key: 'Group',
                                index: 'Group',
                                width: '200px',
                                render(text, row){
                                    return <Form.Item name={[row.name, 'signOffUserGroup']} rules={[{ required: true, message: 'Please select Group' }]}>
                                        <SignOffUserGroup row={row} disabled={formDisabled()} />
                                    </Form.Item>
                                }
                            },
                            {
                                title: <span><span style={{color: '#f5222d'}}>*</span>Signer</span>,
                                key: 'User',
                                index: 'User',
                                width: '200px',
                                render(text, row){
                                    return <Form.Item name={[row.name, 'signOffUser']} rules={[{ required: true, message: 'Please select User' }]}>
                                        <SignOffUser row={row} disabled={formDisabled()} />
                                    </Form.Item>
                                }
                            },
                            {
                                title: <span><span style={{color: '#f5222d'}}>*</span>Artefact</span>,
                                key: 'artifact',
                                width: '200px',
                                index: 'artifact',
                                render(text, row){
                                    return <Form.Item name={[row.name, 'artifact']} rules={[{ required: true, message: 'Please upload artefact' }]}>
                                        <Artefact disabled={formDisabled()} row={row} />
                                    </Form.Item>
                                }
                            },
                            {
                                title: <span>Rejection Reason</span>,
                                key: 'rejectionReason',
                                width: '200px',
                                index: 'rejectionReason',
                                render(text, row){
                                    return <Form.Item name={[row.name, 'rejectionReason']}>
                                        <RejectionReason />
                                    </Form.Item>
                                }
                            },
                            {
                                title: "Actions",
                                key: 'actions',
                                index: 'actions',
                                width: '100px',
                                fixed: 'right',
                                render(text, row){
                                    const tableData = form.getFieldValue('testingSignoff')
                                    const rowData = tableData[row.name] || {}
                                    const approver = rowData.signOffUser?.[0]?.userId
                                    let userInfo = localStorage.getItem('dosm_loginInfo')
                                    userInfo = JSON.parse(userInfo)
                                    const currentUser = userInfo.user.userId
                                    const showSend = () => {
                                        return crStatus && 
                                        (rowData.status === 'WAITSEND' || rowData.status === 'REJECTED') && 
                                        rowData.signOffType && 
                                        rowData.signOffUserGroup &&
                                        rowData.signOffUser && 
                                        currentUser == orderInfo.createdBy
                                    }
                                    return <Space>
                                        {/* <Button icon={<EditOutlined />} style={{border: 'none', background: 'transparent'}}></Button> */}
                                        {
                                            (!crStatus || (crStatus == 'New' && currentUser == orderInfo.createdBy)) &&
                                            rowData.status != 'REJECTED' &&
                                            <Button style={{border: 'none', background: 'transparent'}} onClick={() => {
                                                removeRecord(row)
                                            }}><DeleteOutlined /></Button>
                                        }
                                        {
                                            rowData.status === 'PENDING' && approver == currentUser &&
                                            <Button type="primary" onClick={() => approval(row.name)}>Approve</Button>
                                        }
                                        {
                                            rowData.status === 'PENDING' && approver == currentUser &&
                                            <Button type="danger" ghost onClick={() => reject(row.name)}>Rejected</Button>
                                        }
                                        {
                                            showSend() &&
                                            <Button type="primary" onClick={() => sendEmail(row.name)}>Send</Button>
                                        }
                                    </Space>
                                }
                            }
                        ]}
                        dataSource={fields?.map((i) => ({ ...i, remove, form, signoffTypeOptions: signoffTypeOptions, onValuesChange }))}
                        pagination={false}
                    ></CWTable>
                }}
            </Form.List>
            {
                showAdd() && 
                <Button type="link" size="small" onClick={addRecord}><PlusOutlined />Add</Button>
            }
        </Form>
    </div>
}
export default observer(Signoff);
