import { observable, action } from '@chaoswise/cw-mobx'

class ProjectCutoverSignoffStore {
    @observable formData = {}
    @observable orderInfo = {}

    @action
    updateState = (state) => {
        Object.assign(this, state)
    }
}

export default new ProjectCutoverSignoffStore()
