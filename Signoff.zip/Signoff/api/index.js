import {helper, request} from "@/utils/T";
import { fetchGet, fetchPost, upload } from '@/utils/T/core/request/request';

const { get } = request;
const { encryptByDES } = helper;


// upload file
export const uploadFileList = (params, cb) => {
    return upload(`/api/v2/file/uploadList`, params, cb, {timeout: 5 * 1000});
};
// review file
export const reviewFile = (id) => {
    return `${location.origin}/gateway/dosm/api/v2/online/preview/filePreviewById?fileId=${id}`
};
// download file
export const downloadFile = (id, fileName) => {
    const url = `/api/v2/file/download?id=${id}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.querySelector('body').appendChild(a);
    a.click();
    document.querySelector('body').removeChild(a);

};
// bulk download
export const bulkDownloadFile =(idList, fileName)=>{
    const url = `/api/v2/file/bulkDownload?id=${idList.join(',')}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.querySelector('body').appendChild(a);
    a.click();
    document.querySelector('body').removeChild(a);
}

// query groups with groupid
export const getUserGroupInfoByIds = (params) => {
    return fetchGet(`/api/v2/userGroup/getUserGroupInfoByIds?groupIds=${encryptByDES(params.groupId.toString())}`)
}

// query users with groupid
export const getUsersByGroupId = (groupId) => {
    let _id = encryptByDES(groupId.toString());
    return get(`/api/v2/user/getUsersByGroupId`, {
        groupId:_id,
        currentPageNo:1,
        pageSize:100
    })
}

// insert signoff info
export const signoffInsertBatch = (params) => {
    let workOrderId = params[0].workOrderId
    let signOffGroup = params[0].signOffGroup
    return new Promise((resolve, reject) => {
        getSignOffListByWorkOrderId({workOrderId, signOffGroup}).then(res => {
            if(res && res?.data && res?.data?.length > 0){
                const existTypes = res.data.map(item => JSON.parse(item.signOffType)).flat()
                let newParams = params.filter(item => {
                    let type = JSON.parse(item.signOffType)[0]
                    return !existTypes.includes(type)
                })
                fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/insertBatch`,{data: newParams, baseURL: ''}).then(res => {
                    resolve(res)
                }).catch(err => {
                    reject(err)
                })
            }else{
                fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/insertBatch`,{data: params, baseURL: ''}).then(res => {
                    resolve(res)
                }).catch(err => {
                    reject(err)
                })
            }
        })
    })
}
// delete signoff info
export const signoffDeleteBatch = (params) => {
    return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/deleteBatch`,{data: params, baseURL: ''})
}
// update signoff info
export const signoffUpdate = (params) => {
    return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/update`,{data: params, baseURL: ''})
}
// send email
export const signoffSendEmail = (params) => {
    return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/sendEmail?signOffId=${params.signOffId}`,{data: params,  baseURL: ''})
}

// update signoff status
export const signoffStatus = (params) => {
    return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/status?signOffId=${params.signOffId}&status=${params.status}`,{data: params,  baseURL: ''})
}

// reject
export const signoffRejected = (params) => {
    return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/rejected?signOffId=${params.signOffId}&rejectionReason=${params.rejectionReason}`,{data: params,  baseURL: ''})
}
// approval
export const signoffApproved = (params) => {
    return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/approved?signOffId=${params.signOffId}`,{data: params,  baseURL: ''})
}
// query signoff info by id
export const getSignOffById = (params) => {
    return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/getSignOffById`,{data: params, baseURL: ''})
}
// query signoff list with workOrderId
export const getSignOffListByWorkOrderId = (params) => {
    return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/getSignOffListByWorkOrderId?signOffGroup=${params.signOffGroup}&workOrderId=${params.workOrderId}`,{ baseURL: ''})
}
// submit IDR CASE ID
export const submitIDRCseId = (params) => {
    return new Promise((resolve, reject) => {
        window.fetch(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/idrCaseIdValid?caseId=${params.caseId}`,{
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }).then(res => {
            res.json().then(res => {
                resolve(res.data)
            })
        })
    })
    // return fetchPost(`${window.DOSM_CUSTOM_DBS.basename}/dosm/signOff/idrCaseIdValid?caseId=${params.caseId}`,{data: params, baseURL: ''})
}