const RejectionReason = ({value}) => {
    return <div>{value}</div>
}

export default RejectionReason