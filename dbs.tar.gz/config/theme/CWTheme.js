export default {
    "color": 
    // 原设计色板
    // ["#1e82ff","#ffa560","#7707e1","#d4ff6c","#3246ff","#ff8a00","#ffdb08","#afff6c","#57b7ff","#ffdf00","#ff3332","#6fff6c","#1b7fff","#ff6160","#fff66e","#6cffbd","#60bfff"]
    // antv-g2 第一套色板10色
    ["#5B8FF9","#61DDAA","#65789B","#F6BD16","#7262fd","#78D3F8","#9661BC","#F6903D","#008685","#F08BB4"]
    // antv-g2 第一套色板20色
    // ["#5B8FF9","#CDDDFD","#61DDAA","#CDF3E4","#65789B","#CED4DE","#F6BD16","#FCEBB9","#7262fd","#D3CEFD","#78D3F8","#D3EEF9","#9661BC","#DECFEA","#F6903D","#FFE0C7","#008685","#BBDEDE","#F08BB4","#FFE0ED"]
    ,
    "backgroundColor": "rgba(252,252,252,0)",
    "textStyle": {},
    "title": {
        "textStyle": {
            "color": "#333333"
        },
        "subtextStyle": {
            "color": "#999999"
        }
    },
    "line": {
        "itemStyle": {
            "borderWidth": "1"
        },
        "lineStyle": {
            "width": "2"
        },
        "symbolSize": "7",
        "symbol": "emptyCircle",
        "smooth": true
    },
    "radar": {
        "itemStyle": {
            "borderWidth": "1"
        },
        "lineStyle": {
            "width": "2"
        },
        "symbolSize": "7",
        "symbol": "emptyCircle",
        "smooth": true
    },
    "bar": {
        "itemStyle": {
            "barBorderWidth": "0",
            "barBorderColor": "#ffffff"
        }
    },
    "pie": {
        "itemStyle": {
            "borderWidth": "0",
            "borderColor": "#ffffff"
        }
    },
    "scatter": {
        "itemStyle": {
            "borderWidth": "1",
            "borderColor": "#ffffff"
        }
    },
    "boxplot": {
        "itemStyle": {
            "borderWidth": "1",
            "borderColor": "#ffffff"
        }
    },
    "parallel": {
        "itemStyle": {
            "borderWidth": "1",
            "borderColor": "#ffffff"
        }
    },
    "sankey": {
        "itemStyle": {
            "borderWidth": "1",
            "borderColor": "#ffffff"
        }
    },
    "funnel": {
        "itemStyle": {
            "borderWidth": "1",
            "borderColor": "#ffffff"
        }
    },
    "gauge": {
        "itemStyle": {
            "borderWidth": "1",
            "borderColor": "#ffffff"
        }
    },
    "candlestick": {
        "itemStyle": {
            "color": "#e6a0d2",
            "color0": "transparent",
            "borderColor": "#e6a0d2",
            "borderColor0": "#3fb1e3",
            "borderWidth": "2"
        }
    },
    "graph": {
        "itemStyle": {
            "borderWidth": "1",
            "borderColor": "#ffffff"
        },
        "lineStyle": {
            "width": "1",
            "color": "#cccccc"
        },
        "symbolSize": "7",
        "symbol": "emptyCircle",
        "smooth": true,
        "color": [
            "#3fb1e3",
            "#6be6c1",
            "#626c91",
            "#a0a7e6",
            "#c4ebad",
            "#96dee8"
        ],
        "label": {
            "color": "#ffffff"
        }
    },
    "map": {
        "itemStyle": {
            "normal": {
                "areaColor": "#eeeeee",
                "borderColor": "#aaaaaa",
                "borderWidth": 0.5
            },
            "emphasis": {
                "areaColor": "rgba(63,177,227,0.25)",
                "borderColor": "#3fb1e3",
                "borderWidth": 1
            }
        },
        "label": {
            "normal": {
                "textStyle": {
                    "color": "#ffffff"
                }
            },
            "emphasis": {
                "textStyle": {
                    "color": "#3fb1e3"
                }
            }
        }
    },
    "geo": {
        "itemStyle": {
            "normal": {
                "areaColor": "#eeeeee",
                "borderColor": "#aaaaaa",
                "borderWidth": 0.5
            },
            "emphasis": {
                "areaColor": "rgba(63,177,227,0.25)",
                "borderColor": "#3fb1e3",
                "borderWidth": 1
            }
        },
        "label": {
            "normal": {
                "textStyle": {
                    "color": "#ffffff"
                }
            },
            "emphasis": {
                "textStyle": {
                    "color": "#3fb1e3"
                }
            }
        }
    },
    "categoryAxis": {
        "axisLine": {
            "show": true,
            "lineStyle": {
                "color": "#cccccc"
            }
        },
        "axisTick": {
            "show": true,
            "lineStyle": {
                "color": "#cccccc"
            }
        },
        "axisLabel": {
            "show": true,
            "textStyle": {
                "color": "#777777"
            }
        },
        "splitLine": {
            "show": true,
            "lineStyle": {
                "color": [
                    "#eeeeee"
                ]
            }
        },
        "splitArea": {
            "show": false,
            "areaStyle": {
                "color": [
                    "rgba(250,250,250,0.05)",
                    "rgba(200,200,200,0.02)"
                ]
            }
        }
    },
    "valueAxis": {
        "axisLine": {
            "show": true,
            "lineStyle": {
                "color": "#cccccc"
            }
        },
        "axisTick": {
            "show": true,
            "lineStyle": {
                "color": "#cccccc"
            }
        },
        "axisLabel": {
            "show": true,
            "textStyle": {
                "color": "#777777"
            }
        },
        "splitLine": {
            "show": true,
            "lineStyle": {
                "color": [
                    "#eeeeee"
                ]
            }
        },
        "splitArea": {
            "show": false,
            "areaStyle": {
                "color": [
                    "rgba(250,250,250,0.05)",
                    "rgba(200,200,200,0.02)"
                ]
            }
        }
    },
    "logAxis": {
        "axisLine": {
            "show": true,
            "lineStyle": {
                "color": "#cccccc"
            }
        },
        "axisTick": {
            "show": true,
            "lineStyle": {
                "color": "#cccccc"
            }
        },
        "axisLabel": {
            "show": true,
            "textStyle": {
                "color": "#777777"
            }
        },
        "splitLine": {
            "show": true,
            "lineStyle": {
                "color": [
                    "#eeeeee"
                ]
            }
        },
        "splitArea": {
            "show": false,
            "areaStyle": {
                "color": [
                    "rgba(250,250,250,0.05)",
                    "rgba(200,200,200,0.02)"
                ]
            }
        }
    },
    "timeAxis": {
        "axisLine": {
            "show": true,
            "lineStyle": {
                "color": "#cccccc"
            }
        },
        "axisTick": {
            "show": true,
            "lineStyle": {
                "color": "#cccccc"
            }
        },
        "axisLabel": {
            "show": true,
            "textStyle": {
                "color": "#777777"
            }
        },
        "splitLine": {
            "show": true,
            "lineStyle": {
                "color": [
                    "#eeeeee"
                ]
            }
        },
        "splitArea": {
            "show": false,
            "areaStyle": {
                "color": [
                    "rgba(250,250,250,0.05)",
                    "rgba(200,200,200,0.02)"
                ]
            }
        }
    },
    "toolbox": {
        "iconStyle": {
            "normal": {
                "borderColor": "#888888"
            },
            "emphasis": {
                "borderColor": "#666666"
            }
        }
    },
    "legend": {
        "textStyle": {
            "color": "#999999"
        }
    },
    "tooltip": {
        "backgroundColor": "rgba(255, 255, 255, .95)",
        "padding": [5, 12, 5, 12],
        "extraCssText": "box-shadow: 0 3px 6px -4px rgba(0,0,0,0.12), 0 6px 16px 0 rgba(0,0,0,0.08), 0 9px 28px 8px rgba(0,0,0,0.05);border-radius: 2px",
        "textStyle": {
            "color": "rgba(0, 0, 0, .65)",
            "fontSize": 12,
        },
        "axisPointer": {
            "lineStyle": {
                "color": "#cccccc",
                "width": 1
            },
            "crossStyle": {
                "color": "#cccccc",
                "width": 1
            }
        }
    },
    "timeline": {
        "lineStyle": {
            "color": "#626c91",
            "width": 1
        },
        "itemStyle": {
            "normal": {
                "color": "#d0f9ff",
                "borderWidth": 1
            },
            "emphasis": {
                "color": "#626c91"
            }
        },
        "controlStyle": {
            "normal": {
                "color": "#626c91",
                "borderColor": "#626c91",
                "borderWidth": 0.5
            },
            "emphasis": {
                "color": "#626c91",
                "borderColor": "#626c91",
                "borderWidth": 0.5
            }
        },
        "checkpointStyle": {
            "color": "#3fb1e3",
            "borderColor": "#3fb1e3"
        },
        "label": {
            "normal": {
                "textStyle": {
                    "color": "#626c91"
                }
            },
            "emphasis": {
                "textStyle": {
                    "color": "#626c91"
                }
            }
        }
    },
    "visualMap": {
        "color": [
            "#2a99c9",
            "#afe8ff",
            "#333333"
        ]
    },
    "dataZoom": {
        "backgroundColor": "rgba(255,255,255,0)",
        "dataBackgroundColor": "rgba(222,222,222,1)",
        "fillerColor": "rgba(91,143,249,0.15)",
        "handleColor": "#cccccc",
        "handleSize": "100%",
        "textStyle": {
            "color": "#999999"
        }
    },
    "markPoint": {
        "label": {
            "color": "#ffffff"
        },
        "emphasis": {
            "label": {
                "color": "#ffffff"
            }
        }
    }
}