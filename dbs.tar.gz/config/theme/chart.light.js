import theme from './CWTheme';

export default theme;