"use strict";

require("./index.css");