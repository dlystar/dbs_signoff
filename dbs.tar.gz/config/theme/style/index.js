"use strict";

require("./index.less");