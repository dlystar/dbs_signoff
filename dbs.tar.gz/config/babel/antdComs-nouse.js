/*
 * @Author: your name
 * @Date: 2022-02-21 16:23:43
 * @LastEditTime: 2023-05-11 17:35:05
 * @LastEditors: andrew.qiao andrew.qiao@cloudwise.com
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /change_02/aops_web_commons/packages/ui/config/babel/antdComs.js
 */

module.exports = [
  'Affix', 'Anchor', 'AutoComplete',
  'Avatar', 'BackTop', 'Breadcrumb',
  'Calendar', 'Card', 'Carousel', 'Col',
  'Comment', 'Descriptions',
  'Divider', 'Drawer', 'Dropdown',
  'Icon',
  'List', 'LocaleProvider', 'Layout', 'Mention',
  'Mentions', 'PageHeader', 'Transfer',
  'Popover',
  'Rate', 'Result', 'Row',
  'Skeleton', 'Spin',
  'Statistic', 'Steps', 'Switch', 'TimePicker','TreeSelect',
  'Select',
  'Typography',
  'version', 'Table', 'Tree',
];
// 已经被覆盖的组件
/**
 * Button
 * ConfigProvider
 * Modal
 * Pagination
 * Upload
 * Tree
 * Table
 * Tabs
 * Tooltip
 * Popconfirm
 * Radio
 * Checkbox
 * message
 * Slider
 * Input
 * Progress
 * Badge
 * Alert
 * Menu
 * InputNumber
 * Cascader
 * notification
 */
