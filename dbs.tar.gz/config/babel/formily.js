const fse = require('fs-extra');
// 项目的根目录
const projectPath = process.cwd();

const babelConfig = {
  "libraryName": "@chaoswise/ui/formily",
  "camel2DashComponentName": false,
  "customName": name => {
    return `@chaoswise/ui/lib/Formily/${name}`
  },
  "style": name => {
    // 判断是否有样式文件
    const fileTargetPath = `${projectPath}/node_modules/${name}/index.less`;
    const isExist = fse.pathExistsSync(fileTargetPath);
    if(!isExist) {
      return false
    }
    return `${name}/index.less`
  }
}

module.exports = babelConfig;