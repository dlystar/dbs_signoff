const babelConfig = {
  "libraryName": "@chaoswise/ui",
  "camel2DashComponentName": false,
  "customName": name => {
    return `@chaoswise/ui/lib/${name}`
  }
}

module.exports = babelConfig;
