module.exports = {
  "@chaoswise/ui": {
    "transform": "@chaoswise/ui/lib/{{member}}"
  },
}